# Xiaomi Zoom Tweak — modul LSPosed untuk Kamera Xiaomi 13T

Modul ini dianalisis & dibuat khusus untuk **`com.android.camera` versi 6.1.000650.0**
(APK yang kamu upload). Tujuannya: bikin transisi zoom lebih halus, kecepatan
zoom bisa diatur, dan menambahkan 4 tombol preset zoom (0.6x / 1x / 2x / 5x)
mengambang di atas layar kamera.

## Cara build APK

1. Buka folder ini di **Android Studio** (File → Open → pilih folder `lsposed_project`).
2. Biarkan Gradle sync selesai (butuh koneksi internet untuk download dependency
   `de.robv.android.xposed:api:82` dari `api.xposed.info`, dan library AndroidX).
3. Build → Build Bundle(s) / APK(s) → Build APK(s).
4. APK hasil build ada di `app/build/outputs/apk/debug/app-debug.apk`.
5. Install ke HP, buka **LSPosed Manager** → aktifkan modul "Xiaomi Zoom Tweak"
   → centang scope **Kamera (com.android.camera)** → reboot atau force-stop
   Kamera.
6. Buka app "Xiaomi Zoom Tweak" dari launcher untuk atur kecepatan zoom &
   tampilan tombol preset, lalu tekan **Simpan Pengaturan**.

## Cara kerja (2 lapis hook)

### 1. Hook stabil — level Android API standar
`MainHook` meng-hook `CaptureRequest.Builder.set()` khusus untuk key
`CONTROL_ZOOM_RATIO` (kunci resmi Android Camera2 API, bukan bagian internal
Xiaomi). Di titik inilah nilai rasio zoom "dihaluskan" (exponential smoothing)
atau dibatasi kecepatan perubahannya, sebelum dikirim ke hardware kamera.

**Ini akan tetap berfungsi walau Xiaomi update aplikasi Kamera**, karena tidak
bergantung pada nama class/method internal yang di-obfuscate.

### 2. Hook spesifik build ini — `aa.k` (ZoomManager)
Lewat analisis DEX manual (lihat folder `analysis_notes/`), ditemukan:

| Class (obfuscated) | Peran |
|---|---|
| `aa.a` | interface ZoomManager |
| `aa.k` | implementasi ZoomManager. Method kunci: `onScale(Lg9/c;)Z` (handler pinch), `setZoomRatio(F)V`, `b0(F,I)Z` (penerap rasio), `i0()F` (getter rasio saat ini) |
| `com.android.camera.fragment.dual.FragmentDualCameraAdjust` | Fragment UI zoom utama (`setIsSpeedUp`, `setIsSpeedDown`, `provideAnimateElement`, dll) |
| `com.android.camera.ui.zoom.ZoomRatioToggleView` | Baris tombol toggle zoom bawaan |
| `com.android.camera2.compat.MiCameraCompatBaseImpl` | Jembatan ke vendor tag Camera2 (`applyUserZoom`, `applyIsZoomSpeedUp/Down`, dst) |

Modul ini memakai `aa.k` untuk:
- Menangkap instance ZoomManager yang sedang berjalan (lewat hook constructor),
  supaya tombol overlay 0.6/1/2/5x bisa langsung memanggil `setZoomRatio(float)`.

**PENTING:** nama-nama seperti `aa.k`, `b0`, `i0`, `onScale` adalah hasil
obfuscation (ProGuard/R8) yang **spesifik untuk build 6.1.000650.0**. Kalau
Xiaomi update Kamera, nama-nama ini kemungkinan besar berubah dan hook #2 akan
gagal attach (akan tercatat di log LSPosed, tapi modul tidak crash — hook #1
tetap jalan).

## Kalau app di-update dan hook #2 berhenti bekerja

Saya sertakan `dexparse_tool.py`, tool Python murni (tanpa dependency
eksternal) yang saya tulis untuk membaca struktur class/method langsung dari
file `.dex` tanpa perlu jadx/apktool. Cara pakai:

```bash
# ambil APK baru
adb pull /data/app/~~xxxx/com.android.camera-xxxx/base.apk kamera_baru.apk
unzip kamera_baru.apk -d extracted_baru

# cari ulang class yang punya field/method mengandung kata "zoom"
python3 dexparse_tool.py extracted_baru/classes2.dex zoom

# lihat isi satu class tertentu secara detail (disassembly ringkas)
python3 dexparse_tool.py extracted_baru/classes2.dex "aa/k" disasm
```

Kalau kamu punya akses ke mesin dengan internet (laptop sendiri), jauh lebih
mudah pakai **jadx** (https://github.com/skylot/jadx) untuk decompile penuh ke
Java yang jauh lebih mudah dibaca dibanding disassembly mentah ini — silakan
pakai itu untuk verifikasi ulang nama method sebelum update `MainHook.java`.

## Batasan yang jujur perlu diketahui

- Saya **tidak** punya jadx/apktool di lingkungan kerja saya sekarang (tidak
  ada akses internet untuk install), jadi analisis di atas berasal dari parser
  DEX yang saya tulis sendiri — cukup untuk memetakan class/method/field, tapi
  tidak menunjukkan logika aritmatika detail (misalnya konstanta sensitivitas
  pinch-zoom yang tepat). Untuk penyesuaian yang lebih presisi (misalnya
  benar-benar mengubah kurva sensitivitas pinch), sebaiknya decompile dengan
  jadx di komputer kamu sendiri.
- Posisi & tampilan tombol overlay (garis kode `addZoomOverlay()`) masih
  sangat dasar — silakan sesuaikan margin/gravity/style di `MainHook.java`
  supaya pas dengan layout kamera Xiaomi 13T kamu (notch, safe area, dst
  berbeda-beda).
- `onScale` sudah di-hook tapi belum memodifikasi apapun (placeholder) karena
  logika sensitivitas pinch aslinya belum terverifikasi 100% tanpa jadx.
- Ini murni untuk kustomisasi HP pribadi kamu.
