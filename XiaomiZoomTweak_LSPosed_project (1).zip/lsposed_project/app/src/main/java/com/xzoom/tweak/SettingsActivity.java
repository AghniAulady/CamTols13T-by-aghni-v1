package com.xzoom.tweak;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.util.Locale;

/**
 * Plain settings screen. Values are written to a SharedPreferences file
 * ("zoom_prefs") that is then made world-readable so MainHook (running
 * inside com.android.camera's process via LSPosed) can read it through
 * XSharedPreferences. This is the standard pattern for Xposed/LSPosed
 * modules that need a companion settings UI.
 */
public class SettingsActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "zoom_prefs";

    private SeekBar seekSpeed;
    private TextView tvSpeedValue;
    private Switch switchSmooth;
    private Switch switchOverlay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        seekSpeed = findViewById(R.id.seekSpeed);
        tvSpeedValue = findViewById(R.id.tvSpeedValue);
        switchSmooth = findViewById(R.id.switchSmooth);
        switchOverlay = findViewById(R.id.switchOverlay);
        Button btnSave = findViewById(R.id.btnSave);

        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        float savedSpeed = prefs.getFloat("speed_multiplier", 1.0f);
        boolean savedSmooth = prefs.getBoolean("smooth_enabled", true);
        boolean savedOverlay = prefs.getBoolean("show_overlay", true);

        seekSpeed.setProgress(speedToProgress(savedSpeed));
        updateSpeedLabel(savedSpeed);
        switchSmooth.setChecked(savedSmooth);
        switchOverlay.setChecked(savedOverlay);

        seekSpeed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                updateSpeedLabel(progressToSpeed(progress));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) { }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) { }
        });

        btnSave.setOnClickListener(v -> {
            float speed = progressToSpeed(seekSpeed.getProgress());
            boolean smooth = switchSmooth.isChecked();
            boolean overlay = switchOverlay.isChecked();

            prefs.edit()
                    .putFloat("speed_multiplier", speed)
                    .putBoolean("smooth_enabled", smooth)
                    .putBoolean("show_overlay", overlay)
                    .apply();

            makeWorldReadable();

            Toast.makeText(this,
                    "Tersimpan. Tutup paksa (force-stop) aplikasi Kamera lalu buka lagi.",
                    Toast.LENGTH_LONG).show();
        });
    }

    // progress 0..275  ->  speed 0.25x..3.00x
    private float progressToSpeed(int progress) {
        return (progress + 25) / 100f;
    }

    private int speedToProgress(float speed) {
        return Math.round(speed * 100f) - 25;
    }

    private void updateSpeedLabel(float speed) {
        String tag = speed < 1f ? "(lebih lambat & halus)" : (speed > 1f ? "(lebih cepat)" : "(normal)");
        tvSpeedValue.setText(String.format(Locale.getDefault(), "%.2fx %s", speed, tag));
    }

    /**
     * Standard trick so the app running under a different UID (the Camera
     * app, via LSPosed) can read this SharedPreferences file through
     * XSharedPreferences.
     */
    private void makeWorldReadable() {
        try {
            File prefsDir = new File(getApplicationInfo().dataDir, "shared_prefs");
            File prefsFile = new File(prefsDir, PREFS_NAME + ".xml");
            prefsDir.setExecutable(true, false);
            prefsDir.setReadable(true, false);
            if (prefsFile.exists()) {
                prefsFile.setReadable(true, false);
            }
        } catch (Throwable ignored) {
            // Non-fatal - on some OEM ROMs SELinux may still block XSharedPreferences
            // entirely, which is a known LSPosed limitation, not a bug in this module.
        }
    }
}
