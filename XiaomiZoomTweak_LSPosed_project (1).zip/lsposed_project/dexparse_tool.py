import struct, sys

class DexFile:
    def __init__(self, path):
        with open(path, 'rb') as f:
            self.data = f.read()
        self._parse_header()
        self._parse_strings()
        self._parse_types()
        self._parse_protos()
        self._parse_fields()
        self._parse_methods()
        self._parse_classdefs()

    def u4(self, off): return struct.unpack_from('<I', self.data, off)[0]
    def u2(self, off): return struct.unpack_from('<H', self.data, off)[0]

    def uleb128(self, off):
        result = 0
        shift = 0
        while True:
            b = self.data[off]
            off += 1
            result |= (b & 0x7f) << shift
            if not (b & 0x80):
                break
            shift += 7
        return result, off

    def _parse_header(self):
        d = self.data
        self.string_ids_size = self.u4(0x38)
        self.string_ids_off = self.u4(0x3c)
        self.type_ids_size = self.u4(0x40)
        self.type_ids_off = self.u4(0x44)
        self.proto_ids_size = self.u4(0x48)
        self.proto_ids_off = self.u4(0x4c)
        self.field_ids_size = self.u4(0x50)
        self.field_ids_off = self.u4(0x54)
        self.method_ids_size = self.u4(0x58)
        self.method_ids_off = self.u4(0x5c)
        self.class_defs_size = self.u4(0x60)
        self.class_defs_off = self.u4(0x64)

    def _get_string(self, idx):
        off = self.u4(self.string_ids_off + idx*4)
        length, off2 = self.uleb128(off)
        # MUTF-8 decode till length chars (approx as utf-8, ok for ascii)
        end = off2
        # find null terminator search bounded reasonably
        raw = bytearray()
        i = off2
        while True:
            b = self.data[i]
            if b == 0:
                break
            raw.append(b)
            i += 1
        try:
            return raw.decode('utf-8', errors='replace')
        except:
            return raw.decode('latin1')

    def _parse_strings(self):
        self.strings = [None]*self.string_ids_size
        for i in range(self.string_ids_size):
            self.strings[i] = None  # lazy

    def get_string(self, idx):
        if self.strings[idx] is None:
            self.strings[idx] = self._get_string(idx)
        return self.strings[idx]

    def _parse_types(self):
        self.type_ids = []
        for i in range(self.type_ids_size):
            off = self.type_ids_off + i*4
            descr_idx = self.u4(off)
            self.type_ids.append(descr_idx)

    def type_name(self, type_idx):
        return self.get_string(self.type_ids[type_idx])

    def _parse_protos(self):
        pass # skip detailed, not needed heavily

    def _parse_fields(self):
        self.field_ids = []
        for i in range(self.field_ids_size):
            off = self.field_ids_off + i*8
            class_idx = self.u2(off)
            type_idx = self.u2(off+2)
            name_idx = self.u4(off+4)
            self.field_ids.append((class_idx, type_idx, name_idx))

    def field_name(self, idx):
        c,t,n = self.field_ids[idx]
        return self.get_string(n)

    def _parse_methods(self):
        self.method_ids = []
        for i in range(self.method_ids_size):
            off = self.method_ids_off + i*8
            class_idx = self.u2(off)
            proto_idx = self.u2(off+2)
            name_idx = self.u4(off+4)
            self.method_ids.append((class_idx, proto_idx, name_idx))

    def method_name(self, idx):
        c,p,n = self.method_ids[idx]
        return self.get_string(n)

    def method_class(self, idx):
        c,p,n = self.method_ids[idx]
        return self.type_name(c)

    def _parse_classdefs(self):
        self.class_defs = []
        for i in range(self.class_defs_size):
            off = self.class_defs_off + i*32
            class_idx = self.u4(off)
            access_flags = self.u4(off+4)
            superclass_idx = self.u4(off+8)
            interfaces_off = self.u4(off+12)
            source_file_idx = self.u4(off+16)
            annotations_off = self.u4(off+20)
            class_data_off = self.u4(off+24)
            static_values_off = self.u4(off+28)
            self.class_defs.append(dict(class_idx=class_idx, access_flags=access_flags,
                superclass_idx=superclass_idx, class_data_off=class_data_off))

    def class_name(self, class_def):
        return self.type_name(class_def['class_idx'])

    def parse_class_data(self, off):
        if off == 0:
            return None
        d = self.data
        static_fields_size, off = self.uleb128(off)
        instance_fields_size, off = self.uleb128(off)
        direct_methods_size, off = self.uleb128(off)
        virtual_methods_size, off = self.uleb128(off)

        def parse_encoded_fields(n, off):
            fields = []
            idx = 0
            for _ in range(n):
                diff, off = self.uleb128(off)
                idx += diff
                access_flags, off = self.uleb128(off)
                fields.append((idx, access_flags))
            return fields, off

        def parse_encoded_methods(n, off):
            methods = []
            idx = 0
            for _ in range(n):
                diff, off = self.uleb128(off)
                idx += diff
                access_flags, off = self.uleb128(off)
                code_off, off = self.uleb128(off)
                methods.append((idx, access_flags, code_off))
            return methods, off

        static_fields, off = parse_encoded_fields(static_fields_size, off)
        instance_fields, off = parse_encoded_fields(instance_fields_size, off)
        direct_methods, off = parse_encoded_methods(direct_methods_size, off)
        virtual_methods, off = parse_encoded_methods(virtual_methods_size, off)
        return dict(static_fields=static_fields, instance_fields=instance_fields,
                    direct_methods=direct_methods, virtual_methods=virtual_methods)


if __name__ == '__main__':
    path = sys.argv[1]
    keyword = sys.argv[2] if len(sys.argv) > 2 else 'Zoom'
    dex = DexFile(path)
    for cd in dex.class_defs:
        cname = dex.class_name(cd)
        cdata = dex.parse_class_data(cd['class_data_off'])
        if cdata is None:
            continue
        all_methods = cdata['direct_methods'] + cdata['virtual_methods']
        all_fields = cdata['static_fields'] + cdata['instance_fields']
        matched_methods = [m for m in all_methods if keyword.lower() in dex.method_name(m[0]).lower()]
        matched_fields = [fi for fi in all_fields if keyword.lower() in dex.field_name(fi[0]).lower()]
        if matched_methods or matched_fields or keyword.lower() in cname.lower():
            print(f"CLASS {cname}")
            for fi, af in matched_fields:
                print(f"   FIELD  {dex.field_name(fi)}")
            for mi, af, co in matched_methods:
                print(f"   METHOD {dex.method_name(mi)}  (access=0x{af:x}, code_off=0x{co:x})")

# ---- Extended: proto/method signature + basic disassembly ----

def parse_proto(dex, proto_idx):
    off = dex.proto_ids_off + proto_idx*12
    shorty_idx = dex.u4(off)
    return_type_idx = dex.u4(off+4)
    parameters_off = dex.u4(off+8)
    params = []
    if parameters_off != 0:
        size = dex.u4(parameters_off)
        for i in range(size):
            type_idx = dex.u2(parameters_off + 4 + i*2)
            params.append(dex.type_name(type_idx))
    ret = dex.type_name(return_type_idx)
    return ret, params

def method_full_sig(dex, method_idx):
    c, p, n = dex.method_ids[method_idx]
    name = dex.get_string(n)
    ret, params = parse_proto(dex, p)
    return f"{name}({', '.join(params)}) -> {ret}"

def get_code_item(dex, code_off):
    if code_off == 0:
        return None
    d = dex.data
    registers_size = dex.u2(code_off)
    ins_size = dex.u2(code_off+2)
    outs_size = dex.u2(code_off+4)
    tries_size = dex.u2(code_off+6)
    debug_info_off = dex.u4(code_off+8)
    insns_size = dex.u4(code_off+12)
    insns_off = code_off + 16
    insns = dex.data[insns_off: insns_off + insns_size*2]
    return dict(registers_size=registers_size, ins_size=ins_size, outs_size=outs_size,
                insns_size=insns_size, insns=insns)

def disasm_summary(dex, code_off):
    """Very lightweight disassembler: walks 16-bit code units, and for
    invoke-* / iget* / iput*/ sget*/sput*/ const-string / new-instance
    opcodes extracts the referenced string/field/method/type index.
    Not a full disassembler (doesn't decode every opcode operand length
    correctly for ALL opcodes), but good enough to surface referenced
    methods/fields/strings/types for analysis purposes."""
    ci = get_code_item(dex, code_off)
    if ci is None:
        return []
    insns = ci['insns']
    refs = []
    i = 0
    n = len(insns)
    while i < n:
        op = insns[i]
        # default instruction length 2 bytes (1 code unit) unless known wider
        length = 2
        try:
            if op in (0x1c, 0x1f, 0x22):  # const-class/check-cast/new-instance -> type@BBBB (format 21c)
                idx = insns[i+2] | (insns[i+3] << 8)
                refs.append(('type', dex.type_name(idx)))
                length = 4
            elif op == 0x1a:  # const-string 21c string
                idx = insns[i+2] | (insns[i+3] << 8)
                refs.append(('string', dex.get_string(idx)))
                length = 4
            elif op == 0x1b:  # const-string/jumbo 31c
                idx = insns[i+2] | (insns[i+3] << 8) | (insns[i+4] << 16) | (insns[i+5] << 24)
                refs.append(('string', dex.get_string(idx)))
                length = 6
            elif 0x52 <= op <= 0x6d:  # iinstance ops iget*/iput* 22c format
                idx = insns[i+2] | (insns[i+3] << 8)
                fname = dex.field_name(idx)
                refs.append(('field', fname, 'iget' if op <=0x58 else 'iput'))
                length = 4
            elif 0x60 <= op <= 0x6d:  # sget/sput 21c
                idx = insns[i+2] | (insns[i+3] << 8)
                refs.append(('sfield', dex.field_name(idx)))
                length = 4
            elif 0x6e <= op <= 0x72:  # invoke-virtual/super/direct/static/interface 35c
                idx = insns[i+2] | (insns[i+3] << 8)
                refs.append(('call', dex.method_name(idx), method_full_sig(dex, idx), dex.method_class(idx)))
                length = 6
            elif 0x74 <= op <= 0x78:  # invoke-*/range 3rc
                idx = insns[i+2] | (insns[i+3] << 8)
                refs.append(('call', dex.method_name(idx), method_full_sig(dex, idx), dex.method_class(idx)))
                length = 6
            elif op in (0x14, 0x15):  # const/high16 (32-bit imm) - format 21h/31i
                length = 4 if op==0x15 else 4
            elif op == 0x13:  # const/16
                length = 4
            elif op == 0x12:  # const/4 -- 1 code unit only
                length = 2
            else:
                length = 2
        except Exception:
            length = 2
        i += length
    return refs

if __name__ == '__main__' and len(sys.argv) > 3 and sys.argv[3] == 'disasm':
    path = sys.argv[1]
    target_class = sys.argv[2]
    dex = DexFile(path)
    for cd in dex.class_defs:
        cname = dex.class_name(cd)
        if cname != target_class:
            continue
        cdata = dex.parse_class_data(cd['class_data_off'])
        if not cdata:
            continue
        for mi, af, co in cdata['direct_methods'] + cdata['virtual_methods']:
            sig = method_full_sig(dex, mi)
            print(f"--- METHOD {dex.method_name(mi)}  sig={sig}  access=0x{af:x} code_off=0x{co:x} ---")
            if co:
                for r in disasm_summary(dex, co):
                    print("   ", r)
