package com.example.zoomsmooth

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.os.SystemClock
import android.util.Log
import io.github.libxposed.api.XposedInterface
import io.github.libxposed.api.XposedModule
import java.lang.reflect.Method
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.exp

private const val TAG = "ZoomSmooth"

/**
 * Menghook method zoom-ratio setter di com.android.camera (build 13T
 * 6.1.000650.0) dan mengganti perubahan zoom instan dengan interpolasi
 * exponential-smoothing — meniru persis algoritma yang ditemukan di
 * dalam mod "Camera Zoom Mod 8.0" (CameraZoomHooks.startSmoother /
 * triggerSmoothZoom, hasil bongkar bytecode).
 *
 * Target hasil analisis statis:
 *   Class  : aa.k   (implementasi; interface induk aa.a)
 *   Method : b0(float zoomRatio, int action): boolean
 *
 * Kalau di firmware/versi kamera lain nama class ini berubah, fungsi
 * findTargetMethod() akan fallback mencari lewat SIGNATURE
 * (float, int) -> boolean di beberapa class kandidat lain, mengikuti
 * pendekatan yang sama dipakai mod aslinya.
 */
object ZoomSmoothHook {

    // ---- kandidat class, urutan prioritas (persis strategi mod asli) ----
    private val PRIMARY_CLASS = "aa.k"
    private val FALLBACK_CLASSES = listOf("aa.a", "com.android.camera.module.q0")
    private const val TARGET_METHOD_NAME_HINT = "b0" // nama di build yg kita analisis

    // ---- state smoothing (setara smootherCurrent/Target/Action/Running) ----
    @Volatile private var current: Float = 0f
    @Volatile private var target: Float = 0f
    @Volatile private var action: Int = 0
    @Volatile private var running: Boolean = false
    @Volatile private var lastFrameTime: Long = 0L
    private var animator: ValueAnimator? = null

    // instance & method asli, dipakai smoother utk memanggil ulang scr reflection
    @Volatile private var zoomManagerInstance: Any? = null
    @Volatile private var targetMethod: Method? = null

    // guard re-entrancy: true selagi smoother sendiri yg memanggil method asli
    private val drivingCall = AtomicBoolean(false)

    // durasi transisi (ms) & time-constant, default persis sama dgn mod asli
    private const val DEFAULT_DURATION_MS = 300f
    private const val MIN_DURATION_MS = 1f
    private const val MAX_DURATION_MS = 900f
    private const val TAU_FACTOR = 0.4f
    private const val EPSILON = 0.001f
    private const val MIN_ALPHA = 0.01f
    private const val MAX_DT_MS = 100L
    private const val DEFAULT_DT_MS = 16L

    private var durationMs = DEFAULT_DURATION_MS
    private var tauMs = DEFAULT_DURATION_MS * TAU_FACTOR

    fun install(module: XposedModule, classLoader: ClassLoader) {
        // ---- MODE DIAGNOSTIK v2: trace lintas beberapa class sekaligus ----
        // aa.k.we()/l() ternyata cuma kepanggil sekali pas kamera dibuka
        // (setup awal, nilai selalu 1.0) -- BUKAN jalur pinch-zoom asli.
        // Kandidat baru hasil analisis lebih luas: com.android.camera.module.
        // BaseModule (class UI utama) punya method sendZoomQuickEvent(F,I),
        // onScale(...), onScaleBegin(F,F), maySwitchCameraLens(F,F) -- salah
        // satu dari ini kemungkinan jalur asli pinch-zoom.
        val targets = listOf(
            PRIMARY_CLASS, // "aa.k"
            "com.android.camera.module.BaseModule",
            "fc.a",
            "u6.i"
        )
        var totalHooked = 0
        for (className in targets) {
            val clazz = try {
                Class.forName(className, false, classLoader)
            } catch (e: ClassNotFoundException) {
                Log.e(TAG, "[ZOOM] class $className tidak ketemu, skip")
                continue
            }
            var hookedCount = 0
            for (m in clazz.declaredMethods) {
                val p = m.parameterTypes
                val hasFloat = p.any { it == Float::class.javaPrimitiveType || it == Double::class.javaPrimitiveType }
                val looksLikeScaleCallback = m.name == "onScale" || m.name == "onScaleBegin"
                if (!hasFloat && !looksLikeScaleCallback) continue
                try {
                    m.isAccessible = true
                    module.hook(m)
                        .setExceptionMode(XposedInterface.ExceptionMode.PROTECTIVE)
                        .intercept { chain ->
                            val argsStr = (p.indices).joinToString(",") { i ->
                                try { chain.getArg(i).toString() } catch (t: Throwable) { "?" }
                            }
                            Log.i(TAG, "[TRACE] $className.${m.name}($argsStr)")
                            chain.proceed()
                        }
                    hookedCount++
                } catch (t: Throwable) {
                    Log.e(TAG, "[ZOOM] gagal hook trace $className.${m.name}: ${t.message}")
                }
            }
            Log.i(TAG, "[ZOOM] $className: $hookedCount method di-trace")
            totalHooked += hookedCount
        }
        Log.i(TAG, "[ZOOM] mode diagnostik v2 aktif — total $totalHooked method di-trace lintas ${targets.size} class. Silakan pinch-zoom & cek log [TRACE].")
    }

    private fun installSmoothingMode_UNUSED(module: XposedModule, classLoader: ClassLoader) {
        val method = findTargetMethod(classLoader)
        if (method == null) {
            Log.e(TAG, "[ZOOM] tidak ketemu method target (b0/setZoomRatio signature float,int) — modul tidak aktif")
            return
        }
        targetMethod = method
        method.isAccessible = true

        try {
            module.hook(method)
                .setExceptionMode(XposedInterface.ExceptionMode.PROTECTIVE)
                .intercept { chain ->
                    if (drivingCall.get()) {
                        // Ini panggilan yang berasal dari smoother kita sendiri
                        // (lihat driveOriginalCall) -> lewatkan apa adanya.
                        return@intercept chain.proceed()
                    }
                    // Panggilan asli dari UI kamera (pinch/slider/tombol zoom):
                    // JANGAN proceed sekarang. Simpan target, biarkan smoother
                    // yang memanggil method asli berkali-kali dgn nilai halus.
                    zoomManagerInstance = chain.thisObject
                    val requestedZoom = (chain.getArg(0) as Number).toFloat()
                    val requestedAction = (chain.getArg(1) as Number).toInt()
                    Log.i(TAG, "[ZOOM] >> b0 dipanggil UI: zoom=$requestedZoom action=$requestedAction")
                    retarget(requestedZoom, requestedAction)
                    // Nilai kembalian method aslinya boolean (indikasi "diterima").
                    true
                }
            Log.i(TAG, "[ZOOM] ✓ hooked ${method.declaringClass.name}.${method.name}(float,int) — smooth zoom aktif")
        } catch (t: Throwable) {
            Log.e(TAG, "[ZOOM] gagal hook ${method.declaringClass.name}.${method.name}: ${t.message}")
        }
    }

    /** Cari method dgn nama hint dulu, kalau tidak ada fallback cari lewat signature murni. */
    private fun findTargetMethod(classLoader: ClassLoader): Method? {
        val classNames = listOf(PRIMARY_CLASS) + FALLBACK_CLASSES
        for (className in classNames) {
            val clazz = try {
                Class.forName(className, false, classLoader)
            } catch (e: ClassNotFoundException) {
                continue
            }
            // 1) coba nama persis dulu
            clazz.declaredMethods.firstOrNull { m ->
                m.name == TARGET_METHOD_NAME_HINT && matchesSignature(m)
            }?.let { return it }
            // 2) fallback: cari method APA SAJA di class ini yg signature-nya cocok
            clazz.declaredMethods.firstOrNull { m -> matchesSignature(m) }?.let { return it }
        }
        return null
    }

    private fun matchesSignature(m: Method): Boolean {
        val p = m.parameterTypes
        return p.size == 2 &&
            p[0] == Float::class.javaPrimitiveType &&
            p[1] == Int::class.javaPrimitiveType &&
            m.returnType == Boolean::class.javaPrimitiveType
    }

    // ---------------- smoothing engine (identik dgn hasil bongkar) ----------------

    private fun retarget(newTarget: Float, newAction: Int) {
        if (!running) {
            current = newTarget // frame pertama: mulai dari nilai yg diminta jg biar tdk "lompat mundur"
        }
        target = newTarget
        action = newAction
        durationMs = DEFAULT_DURATION_MS.coerceIn(MIN_DURATION_MS, MAX_DURATION_MS)
        tauMs = durationMs * TAU_FACTOR
        startSmoother()
    }

    private fun startSmoother() {
        running = true
        lastFrameTime = 0L
        animator?.cancel()

        val va = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 60_000L // cuma "ticker" pengaman; posisi riil dihitung manual di update listener
            addUpdateListener { onFrame() }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: Animator) { running = false }
                override fun onAnimationCancel(a: Animator) { running = false }
            })
        }
        animator = va
        va.start()
    }

    private fun onFrame() {
        val now = SystemClock.uptimeMillis()
        val dt = if (lastFrameTime == 0L) DEFAULT_DT_MS
                 else (now - lastFrameTime).coerceIn(1L, MAX_DT_MS)
        lastFrameTime = now

        val alpha = (1f - exp(-dt / tauMs)).coerceIn(MIN_ALPHA, 1f)
        current += (target - current) * alpha

        if (abs(target - current) < EPSILON) {
            current = target
            driveOriginalCall(current, action)
            animator?.cancel()
        } else {
            driveOriginalCall(current, action)
        }
    }

    private var frameLogCounter = 0

    private fun driveOriginalCall(zoom: Float, act: Int) {
        val method = targetMethod ?: return
        val instance = zoomManagerInstance ?: return
        drivingCall.set(true)
        try {
            val result = method.invoke(instance, zoom, act)
            // Biar logcat gak banjir, cuma log tiap ~10 frame + selalu log frame
            // terakhir (saat animator berhenti / running == false).
            frameLogCounter++
            if (frameLogCounter % 10 == 0 || !running) {
                Log.i(TAG, "[ZOOM] << frame#$frameLogCounter current=$zoom target=$target result=$result running=$running")
            }
            if (!running) frameLogCounter = 0
        } catch (t: Throwable) {
            Log.e(TAG, "[ZOOM] gagal apply zoom halus: ${t.message}")
        } finally {
            drivingCall.set(false)
        }
    }
}
