package com.example.zoomsmooth

import io.github.libxposed.api.XposedModule
import io.github.libxposed.api.XposedModuleInterface.ModuleLoadedParam
import io.github.libxposed.api.XposedModuleInterface.PackageLoadedParam

/**
 * Entry point modul LSPosed untuk Xiaomi 13T (com.android.camera).
 *
 * Direplikasi dari mod "Camera Zoom Mod 8.0" (awalnya untuk Poco F7),
 * dengan target class/method hasil analisis statis terhadap
 * Kamera_6_1_000650_0.apk (build camera bawaan 13T):
 *
 *   aa.k -> b0(float zoomRatio, int action): boolean
 *
 * PENTING: nama class "aa.k" adalah hasil obfuscation R8 dari build
 * APK Camera INI SAJA (6.1.000650.0). Kalau kamera di-update lewat
 * Play Store / OTA, nama ini BISA berubah lagi. Jalankan
 * `adb logcat -s ZoomSmooth` setelah install untuk memastikan hook
 * berhasil ("[ZOOM] hooked ..." vs "[ZOOM] FAILED ...").
 */
class HookEntry(base: io.github.libxposed.api.XposedInterface, param: ModuleLoadedParam) :
    XposedModule(base, param) {

    override fun onPackageLoaded(param: PackageLoadedParam) {
        super.onPackageLoaded(param)
        if (param.packageName != "com.android.camera") {
            // Modul ini cuma untuk app kamera bawaan; app lain diabaikan.
            return
        }
        log("ZoomSmooth: com.android.camera loaded, installing zoom hook")
        ZoomSmoothHook.install(this, param.classLoader)
    }
}
