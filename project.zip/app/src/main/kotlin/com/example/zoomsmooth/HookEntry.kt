package com.example.zoomsmooth

import android.util.Log
import io.github.libxposed.api.XposedModule
import io.github.libxposed.api.XposedModuleInterface.PackageLoadedParam

private const val TAG = "ZoomSmooth"

/**
 * Entry point modul LSPosed untuk Xiaomi 13T (com.android.camera).
 *
 * Direplikasi dari mod "Camera Zoom Mod 8.0" (awalnya untuk Poco F7),
 * dengan target class/method hasil analisis statis terhadap
 * Kamera_6_1_000650_0.apk (build camera bawaan 13T):
 *
 *   aa.k -> b0(float zoomRatio, int action): boolean
 *
 * PENTING: nama class "aa.k" adalah hasil obfuscation R8 dari build
 * APK Camera INI SAJA (6.1.000650.0). Kalau kamera di-update lewat
 * Play Store / OTA, nama ini BISA berubah lagi. Jalankan
 * `adb logcat -s ZoomSmooth` setelah install untuk memastikan hook
 * berhasil ("[ZOOM] hooked ..." vs "[ZOOM] tidak ketemu ...").
 *
 * CATATAN VERSI API: XposedModule di versi libxposed yang dipakai
 * proyek ini TIDAK menerima parameter di constructor (framework
 * memanggil attachFramework() otomatis) -- makanya constructor di
 * bawah ini kosong, bukan HookEntry(base, param).
 */
class HookEntry : XposedModule() {

    override fun onPackageLoaded(param: PackageLoadedParam) {
        super.onPackageLoaded(param)
        if (param.packageName != "com.android.camera") {
            // Modul ini cuma untuk app kamera bawaan; app lain diabaikan.
            return
        }
        Log.i(TAG, "ZoomSmooth: com.android.camera loaded, installing zoom hook")
        ZoomSmoothHook.install(this, param.classLoader)
    }
}
