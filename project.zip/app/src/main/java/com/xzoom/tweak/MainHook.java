package com.xzoom.tweak;

import android.app.Activity;
import android.hardware.camera2.CaptureRequest;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import java.util.concurrent.atomic.AtomicReference;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XSharedPreferences;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * LSPosed module for Kamera Xiaomi (com.android.camera).
 *
 * Analyzed against APK version 6.1.000650.0. Two layers of hooks are used:
 *
 *  1) PRIORITY hook on
 *     com.android.camera2.compat.MiCameraCompatBaseImpl#applyUserZoom(
 *     CaptureRequest.Builder, float). Confirmed via static analysis to be
 *     the actual method Xiaomi's camera pipeline calls every frame to push
 *     the live zoom ratio. This is where "zoom speed" and "smoothing" are
 *     implemented. (A previous version of this module hooked the standard
 *     Camera2 CONTROL_ZOOM_RATIO key directly, but this app never calls
 *     that key path, so that hook never fired - fixed here.)
 *
 *  2) App-internal hooks on the obfuscated ZoomManager class ("aa.k") that
 *     were identified via static analysis of this specific APK build. These
 *     are used only to (a) grab a live ZoomManager instance so our overlay
 *     buttons can call setZoomRatio() directly, and (b) as a placeholder for
 *     future fine-tuning. If Xiaomi updates the Camera app, the obfuscated
 *     name "aa.k" will very likely change and this layer will simply fail to
 *     attach (logged, not fatal) - hook #1 keeps working regardless.
 */
public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "XZoomTweak";
    private static final String TARGET_PACKAGE = "com.android.camera";

    // Obfuscated class name for the ZoomManager implementation, valid for
    // Kamera 6.1.000650.0. Re-check with the dex analysis steps in
    // README.md if this ever stops working after an app update.
    private static final String ZOOM_MANAGER_CLASS = "aa.k";
    private static final String CAMERA_ACTIVITY_CLASS = "com.android.camera.Camera";

    private static XSharedPreferences prefs;
    private static final AtomicReference<Object> zoomManagerRef = new AtomicReference<>();

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        // Unconditional log FIRST, before any check, so we can confirm from
        // the log alone that LSPosed is actually invoking this method at all
        // for this process - regardless of what happens afterwards.
        XposedBridge.log(TAG + " handleLoadPackage() called for package=[" + lpparam.packageName + "]"
                + " process=[" + lpparam.processName + "]");

        if (!TARGET_PACKAGE.equals(lpparam.packageName)) {
            return;
        }

        XposedBridge.log(TAG + " " + ("Package matched (" + TARGET_PACKAGE + ")."));

        // IMPORTANT: don't resolve app-internal classes (aa.k,
        // MiCameraCompatBaseImpl, ...) here directly. handleLoadPackage()
        // fires at the very earliest point of the app process's lifecycle -
        // potentially before the app has finished setting up all of its own
        // classloaders/dynamic modules. Instead, we hook Application#onCreate
        // and do all our class-dependent setup from AFTER it, which is the
        // standard, safer pattern for Xposed/LSPosed modules and avoids
        // spurious "class not found" failures caused purely by timing.
        try {
            XposedHelpers.findAndHookMethod(
                    android.app.Application.class, "onCreate",
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            XposedBridge.log(TAG + " " + ("Application#onCreate finished - installing hooks now."));
                            installAllHooks(lpparam);
                        }
                    });
            XposedBridge.log(TAG + " " + ("Application#onCreate hook installed - will set up feature hooks after it fires."));
        } catch (Throwable t) {
            // Extremely unlikely (Application#onCreate always exists), but if
            // this somehow fails, fall back to installing immediately so the
            // module doesn't end up doing nothing at all.
            XposedBridge.log(TAG + " Could not hook Application#onCreate, falling back to immediate setup: " + t);
            installAllHooks(lpparam);
        }
    }

    private void installAllHooks(XC_LoadPackage.LoadPackageParam lpparam) {
        // Wrap EVERYTHING in try/catch so that any hidden exception gets
        // logged instead of silently aborting the module with no trace.
        try {
            try {
                prefs = new XSharedPreferences("com.xzoom.tweak", "zoom_prefs");
                prefs.makeWorldReadable();
                XposedBridge.log(TAG + " " + ("XSharedPreferences initialised OK"));
            } catch (Throwable t) {
                XposedBridge.log(TAG + " XSharedPreferences init FAILED (using defaults): " + t);
            }

            hookCaptureRequestZoom(lpparam);
            hookZoomManagerInternal(lpparam);
            hookActivityForOverlay(lpparam);
            hookDiagnosticLogging(lpparam);

            XposedBridge.log(TAG + " " + ("All hook setup calls completed without a fatal exception."));
        } catch (Throwable t) {
            XposedBridge.log(TAG + " FATAL error in installAllHooks: " + t);
            XposedBridge.log(TAG + " " + ("FATAL error in installAllHooks") + ": " + t);
        }
    }

    // ---------------------------------------------------------------
    // 0) DIAGNOSTIC LOGGING - hooks a wide net of zoom-related methods
    //    across all the classes found via static analysis, and logs every
    //    call with its arguments. This does NOT modify any behaviour - it
    //    only observes. Use this to find out, from real runtime evidence,
    //    exactly which method actually fires when you pinch-zoom on your
    //    specific phone/ROM, instead of guessing from static analysis alone.
    //
    //    HOW TO USE: install this build, open Kamera, pinch-zoom in/out a
    //    few times over ~5 seconds, then check LSPosed Manager > Logs and
    //    search for "DIAG". Send those lines back so the real call chain
    //    can be pinpointed precisely.
    // ---------------------------------------------------------------
    private void hookDiagnosticLogging(XC_LoadPackage.LoadPackageParam lpparam) {
        // (a) Log every CaptureRequest.Builder.set() call whose key name
        //     contains "zoom" - catches BOTH the standard Camera2 key and
        //     any vendor/proprietary key, whatever its real name is.
        try {
            XposedHelpers.findAndHookMethod(
                    CaptureRequest.Builder.class, "set",
                    CaptureRequest.Key.class, Object.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            try {
                                CaptureRequest.Key<?> key = (CaptureRequest.Key<?>) param.args[0];
                                if (key == null) return;
                                String name = key.getName();
                                if (name != null && name.toLowerCase().contains("zoom")) {
                                    XposedBridge.log(TAG + " " + ("DIAG CaptureRequest.set key=" + name + " value=" + param.args[1]));
                                }
                            } catch (Throwable ignored) {
                            }
                        }
                    });
            XposedBridge.log(TAG + " " + ("DIAG hook on CaptureRequest.Builder.set installed"));
        } catch (Throwable t) {
            XposedBridge.log(TAG + " DIAG hook(a) failed: " + t);
        }

        // (b) Log every method containing "zoom" in MiCameraCompatBaseImpl.
        hookAllZoomMethodsAndLog(lpparam, MI_CAMERA_COMPAT_CLASS, "MiCameraCompat");

        // (c) Log EVERY method in aa.k (ZoomManager) - not just ones with
        //     "zoom" in the name, since this class is obfuscated and its
        //     method names are meaningless single/double letters.
        hookAllMethodsAndLog(lpparam, ZOOM_MANAGER_CLASS, "ZoomManager(aa.k)");

        // (d) Log every method containing "zoom" in the main zoom UI fragment.
        hookAllZoomMethodsAndLog(lpparam,
                "com.android.camera.fragment.dual.FragmentDualCameraAdjust", "FragmentDualCameraAdjust");

        // (e) Log every method containing "zoom" in the toggle-button view.
        hookAllZoomMethodsAndLog(lpparam,
                "com.android.camera.ui.zoom.ZoomRatioToggleView", "ZoomRatioToggleView");
    }

    private void hookAllZoomMethodsAndLog(XC_LoadPackage.LoadPackageParam lpparam, String className, String shortTag) {
        try {
            Class<?> clazz = XposedHelpers.findClass(className, lpparam.classLoader);
            int count = 0;
            for (java.lang.reflect.Method m : clazz.getDeclaredMethods()) {
                if (!m.getName().toLowerCase().contains("zoom")) continue;
                final String methodName = m.getName();
                try {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            XposedBridge.log(TAG + " DIAG " + shortTag + "." + methodName
                                    + " args=" + java.util.Arrays.toString(param.args));
                        }
                    });
                    count++;
                } catch (Throwable ignored) {
                    // some methods (e.g. synthetic/bridge) may fail to hook; skip them
                }
            }
            XposedBridge.log(TAG + " " + ("DIAG hooked " + count + " zoom-named method(s) in " + shortTag));
        } catch (Throwable t) {
            XposedBridge.log(TAG + " DIAG could not load class " + className + ": " + t);
        }
    }

    private void hookAllMethodsAndLog(XC_LoadPackage.LoadPackageParam lpparam, String className, String shortTag) {
        try {
            Class<?> clazz = XposedHelpers.findClass(className, lpparam.classLoader);
            int count = 0;
            for (java.lang.reflect.Method m : clazz.getDeclaredMethods()) {
                final String methodName = m.getName();
                try {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            XposedBridge.log(TAG + " DIAG " + shortTag + "." + methodName
                                    + " args=" + java.util.Arrays.toString(param.args));
                        }
                    });
                    count++;
                } catch (Throwable ignored) {
                }
            }
            XposedBridge.log(TAG + " " + ("DIAG hooked " + count + " method(s) in " + shortTag));
        } catch (Throwable t) {
            XposedBridge.log(TAG + " DIAG could not load class " + className + ": " + t);
        }
    }

    // ---------------------------------------------------------------
    // 1) PRIORITY HOOK: smoothing applied to whichever MiCameraCompatBaseImpl
    //    method(s) actually carry the live zoom ratio on THIS device/ROM.
    //
    //    Confirmed via real on-device diagnostic logs (not just static
    //    analysis) that during a live pinch/drag zoom, applyTrackFocusZoom(
    //    Builder, float) fires repeatedly with a changing float value -
    //    that is the real target. applyUserZoom was our first guess from
    //    static analysis alone but never actually fired in your log, so it's
    //    kept hooked too (in case other zoom modes use it) but is no longer
    //    the only bet.
    // ---------------------------------------------------------------
    private static final String MI_CAMERA_COMPAT_CLASS =
            "com.android.camera2.compat.MiCameraCompatBaseImpl";

    private static final java.util.Map<String, Float> lastAppliedByMethod = new java.util.concurrent.ConcurrentHashMap<>();
    private static final java.util.Map<String, Float> lastLoggedByMethod = new java.util.concurrent.ConcurrentHashMap<>();

    private void hookCaptureRequestZoom(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            Class<?> compatClass = XposedHelpers.findClass(MI_CAMERA_COMPAT_CLASS, lpparam.classLoader);
            installSmoothingHook(compatClass, "applyTrackFocusZoom");
            installSmoothingHook(compatClass, "applyUserZoom");
        } catch (Throwable t) {
            XposedBridge.log(TAG + " Failed to load " + MI_CAMERA_COMPAT_CLASS + ": " + t);
        }
    }

    private void installSmoothingHook(Class<?> compatClass, String methodName) {
        try {
            XposedHelpers.findAndHookMethod(
                    compatClass,
                    methodName,
                    CaptureRequest.Builder.class,
                    float.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            try {
                                float targetRatio = (Float) param.args[1];
                                // alpha: how much of the remaining gap to the target ratio
                                // is closed on every single call. 1.0 = jump straight to the
                                // target (stock behaviour, no smoothing). 0.02 = only close 2%
                                // of the gap each call -> very slow, very smooth motion.
                                float alpha = clamp(getAlpha(), 0.003f, 1.0f);

                                float lastLogged = lastLoggedByMethod.getOrDefault(methodName, -999f);
                                if (Math.abs(targetRatio - lastLogged) > 0.02f) {
                                    lastLoggedByMethod.put(methodName, targetRatio);
                                    XposedBridge.log(TAG + " " + methodName + " called, target=" + targetRatio
                                            + " alpha=" + alpha);
                                }

                                float lastApplied = lastAppliedByMethod.getOrDefault(methodName, -1f);

                                float newRatio = targetRatio;
                                if (lastApplied > 0f && alpha < 1.0f) {
                                    // Exponential smoothing towards the target ratio.
                                    newRatio = lastApplied + (targetRatio - lastApplied) * alpha;
                                }
                                lastAppliedByMethod.put(methodName, newRatio);
                                param.args[1] = newRatio;
                            } catch (Throwable t) {
                                XposedBridge.log(TAG + " " + methodName + " smoothing error: " + t);
                            }
                        }
                    }
            );
            XposedBridge.log(TAG + " " + (MI_CAMERA_COMPAT_CLASS + "." + methodName + " hooked OK"));
        } catch (Throwable t) {
            XposedBridge.log(TAG + " Failed to hook " + methodName + " (app may have updated): " + t);
        }
    }

    // ---------------------------------------------------------------
    // 2) VERSION-SPECIFIC HOOK: aa.k (ZoomManager)
    // ---------------------------------------------------------------
    private void hookZoomManagerInternal(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            Class<?> zoomManagerClass = XposedHelpers.findClass(ZOOM_MANAGER_CLASS, lpparam.classLoader);

            XposedBridge.hookAllConstructors(zoomManagerClass, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    zoomManagerRef.set(param.thisObject);
                    XposedBridge.log(TAG + " " + ("Captured ZoomManager instance: " + param.thisObject));
                }
            });

            try {
                XposedHelpers.findAndHookMethod(zoomManagerClass, "onScale", "g9.c",
                        new XC_MethodHook() {
                            @Override
                            protected void beforeHookedMethod(MethodHookParam param) {
                                // Reserved: fine-grained pinch-gesture speed tuning could
                                // go here once the exact scale-delta math is confirmed
                                // (needs a real decompiler like jadx to read safely).
                            }
                        });
                XposedBridge.log(TAG + " " + ("aa.k.onScale hooked OK"));
            } catch (Throwable t) {
                XposedBridge.log(TAG + " aa.k.onScale hook failed (app may have updated): " + t);
            }

        } catch (Throwable t) {
            XposedBridge.log(TAG + " ZoomManager (" + ZOOM_MANAGER_CLASS + ") not found - " +
                    "internal hooks skipped. Expected if Xiaomi updated the Camera app: " + t);
        }
    }

    // ---------------------------------------------------------------
    // 3) UI: floating preset buttons 0.6x / 1x / 2x / 5x
    // ---------------------------------------------------------------
    private void hookActivityForOverlay(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            // Hook the base Activity class's onResume() instead of guessing an
            // exact subclass method. This is guaranteed to exist (it's declared
            // directly on android.app.Activity), so it can't throw
            // NoSuchMethodError regardless of how Xiaomi structured their
            // Camera/CameraActivity/Fragment hierarchy internally. We then
            // filter to only act on activities that belong to the camera app's
            // own package, so it doesn't affect other apps or unrelated
            // activities within this same process.
            XposedHelpers.findAndHookMethod(Activity.class, "onResume", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    try {
                        if (!getShowOverlay()) return;
                        Activity activity = (Activity) param.thisObject;
                        String className = activity.getClass().getName();
                        if (!className.startsWith("com.android.camera")) return;
                        XposedBridge.log(TAG + " " + ("onResume fired for " + className));
                        addZoomOverlay(activity);
                    } catch (Throwable t) {
                        XposedBridge.log(TAG + " overlay inject error: " + t);
                    }
                }
            });
            XposedBridge.log(TAG + " " + ("Activity#onResume hooked OK (filtering by com.android.camera.*)"));
        } catch (Throwable t) {
            XposedBridge.log(TAG + " Failed to hook Activity#onResume: " + t);
        }
    }

    private static final String OVERLAY_TAG = "xzoom_overlay_bar";

    private void addZoomOverlay(Activity activity) {
        ViewGroup root = activity.findViewById(android.R.id.content);
        if (root == null) return;
        // Tag-based check instead of a single static flag: correctly re-adds
        // the overlay if the Activity is recreated (e.g. rotation), but
        // avoids duplicating it on repeated onResume calls for the same
        // instance.
        if (root.findViewWithTag(OVERLAY_TAG) != null) return;

        LinearLayout bar = new LinearLayout(activity);
        bar.setTag(OVERLAY_TAG);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setBackgroundColor(0x66000000);
        bar.setPadding(24, 12, 24, 12);

        float[] presets = {0.6f, 1f, 2f, 5f};
        for (float ratio : presets) {
            Button btn = new Button(activity);
            String label = (ratio == Math.floor(ratio)) ? ((int) ratio) + "x" : ratio + "x";
            btn.setText(label);
            btn.setAllCaps(false);
            btn.setTextColor(0xFFFFFFFF);
            btn.setBackgroundColor(0x00000000);
            btn.setOnClickListener(v -> applyZoomRatio(ratio));
            LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            btnLp.leftMargin = 8;
            btnLp.rightMargin = 8;
            bar.addView(btn, btnLp);
        }

        if (root instanceof FrameLayout) {
            FrameLayout.LayoutParams flp = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            flp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
            flp.topMargin = 120;
            root.addView(bar, flp);
        } else {
            root.addView(bar);
        }
    }

    private void applyZoomRatio(float ratio) {
        try {
            Object zm = zoomManagerRef.get();
            if (zm == null) {
                XposedBridge.log(TAG + " ZoomManager instance not captured yet, cannot set ratio");
                return;
            }
            XposedHelpers.callMethod(zm, "setZoomRatio", ratio);
            XposedBridge.log(TAG + " " + ("Applied zoom ratio " + ratio + "x via overlay button"));
        } catch (Throwable t) {
            XposedBridge.log(TAG + " applyZoomRatio failed: " + t);
        }
    }

    // ---------------------------------------------------------------
    // Preferences
    // ---------------------------------------------------------------
    private static float getAlpha() {
        try {
            prefs.reload();
            return prefs.getFloat("zoom_alpha", 0.14f); // default: fairly smooth, not extreme
        } catch (Throwable t) {
            return 0.14f;
        }
    }

    private static boolean getShowOverlay() {
        try {
            prefs.reload();
            return prefs.getBoolean("show_overlay", true);
        } catch (Throwable t) {
            return true;
        }
    }

    private static float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }
}
