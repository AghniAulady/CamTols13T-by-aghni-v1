package com.xzoom.tweak;

import android.animation.ValueAnimator;
import android.app.Activity;
import android.hardware.camera2.CaptureRequest;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import java.lang.reflect.Method;
import java.util.concurrent.atomic.AtomicReference;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * LSPosed module for Kamera Xiaomi (com.android.camera).
 *
 * Analyzed against APK version 6.1.000650.0. Two layers of hooks are used:
 *
 *  1) PRIORITY hook on
 *     com.android.camera2.compat.MiCameraCompatBaseImpl#applyUserZoom(
 *     CaptureRequest.Builder, float). Confirmed via static analysis to be
 *     the actual method Xiaomi's camera pipeline calls every frame to push
 *     the live zoom ratio. This is where "zoom speed" and "smoothing" are
 *     implemented. (A previous version of this module hooked the standard
 *     Camera2 CONTROL_ZOOM_RATIO key directly, but this app never calls
 *     that key path, so that hook never fired - fixed here.)
 *
 *  2) App-internal hooks on the obfuscated ZoomManager class ("aa.k") that
 *     were identified via static analysis of this specific APK build. These
 *     are used only to (a) grab a live ZoomManager instance so our overlay
 *     buttons can call setZoomRatio() directly, and (b) as a placeholder for
 *     future fine-tuning. If Xiaomi updates the Camera app, the obfuscated
 *     name "aa.k" will very likely change and this layer will simply fail to
 *     attach (logged, not fatal) - hook #1 keeps working regardless.
 */
public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "XZoomTweak";
    private static final String TARGET_PACKAGE = "com.android.camera";

    // Obfuscated class name for the ZoomManager implementation, valid for
    // Kamera 6.1.000650.0. Re-check with the dex analysis steps in
    // README.md if this ever stops working after an app update.
    private static final String ZOOM_MANAGER_CLASS = "aa.k";
    private static final String MI_CAMERA_COMPAT_CLASS =
            "com.android.camera2.compat.MiCameraCompatBaseImpl";
    private static final String CAMERA_ACTIVITY_CLASS = "com.android.camera.Camera";

    private static volatile android.content.Context appContext;
    // Cross-process settings (XSharedPreferences, then ContentProvider) both
    // turned out to be blocked on this device/ROM (confirmed via logs: the
    // ContentProvider query returns a NULL cursor - almost certainly Android
    // package-visibility filtering blocking com.android.camera from seeing
    // this module's provider). Rather than keep fighting that, this value
    // is hardcoded directly for now so we can conclusively test whether
    // b0(float,int) smoothing is capable of producing a felt delay at all,
    // independent of the (currently non-functional) settings screen.
    private static volatile float cachedDurationMs = 1500f;
    private static volatile boolean cachedShowOverlay = true;
    private static volatile long lastPrefsQueryTime = 0;
    private static final long PREFS_CACHE_MS = 1000; // don't IPC-query on every call
    private static final AtomicReference<Object> zoomManagerRef = new AtomicReference<>();

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        // Unconditional log FIRST, before any check, so we can confirm from
        // the log alone that LSPosed is actually invoking this method at all
        // for this process - regardless of what happens afterwards.
        XposedBridge.log(TAG + " handleLoadPackage() called for package=[" + lpparam.packageName + "]"
                + " process=[" + lpparam.processName + "]");

        if (!TARGET_PACKAGE.equals(lpparam.packageName)) {
            return;
        }

        XposedBridge.log(TAG + " " + ("Package matched (" + TARGET_PACKAGE + ")."));

        // IMPORTANT: don't resolve app-internal classes (aa.k,
        // MiCameraCompatBaseImpl, ...) here directly. handleLoadPackage()
        // fires at the very earliest point of the app process's lifecycle -
        // potentially before the app has finished setting up all of its own
        // classloaders/dynamic modules. Instead, we hook Application#onCreate
        // and do all our class-dependent setup from AFTER it, which is the
        // standard, safer pattern for Xposed/LSPosed modules and avoids
        // spurious "class not found" failures caused purely by timing.
        try {
            XposedHelpers.findAndHookMethod(
                    android.app.Application.class, "onCreate",
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            XposedBridge.log(TAG + " " + ("Application#onCreate finished - installing hooks now."));
                            installAllHooks(lpparam);
                        }
                    });
            XposedBridge.log(TAG + " " + ("Application#onCreate hook installed - will set up feature hooks after it fires."));
        } catch (Throwable t) {
            // Extremely unlikely (Application#onCreate always exists), but if
            // this somehow fails, fall back to installing immediately so the
            // module doesn't end up doing nothing at all.
            XposedBridge.log(TAG + " Could not hook Application#onCreate, falling back to immediate setup: " + t);
            installAllHooks(lpparam);
        }
    }

    private void installAllHooks(XC_LoadPackage.LoadPackageParam lpparam) {
        // Wrap EVERYTHING in try/catch so that any hidden exception gets
        // logged instead of silently aborting the module with no trace.
        try {
            hookCaptureRequestZoom(lpparam);
            hookZoomManagerInternal(lpparam);
            hookActivityForOverlay(lpparam);
            hookDiagnosticLogging(lpparam);

            XposedBridge.log(TAG + " " + ("All hook setup calls completed without a fatal exception."));
        } catch (Throwable t) {
            XposedBridge.log(TAG + " FATAL error in installAllHooks: " + t);
            XposedBridge.log(TAG + " " + ("FATAL error in installAllHooks") + ": " + t);
        }
    }

    // ---------------------------------------------------------------
    // 0) DIAGNOSTIC LOGGING - hooks a wide net of zoom-related methods
    //    across all the classes found via static analysis, and logs every
    //    call with its arguments. This does NOT modify any behaviour - it
    //    only observes. Use this to find out, from real runtime evidence,
    //    exactly which method actually fires when you pinch-zoom on your
    //    specific phone/ROM, instead of guessing from static analysis alone.
    //
    //    HOW TO USE: install this build, open Kamera, pinch-zoom in/out a
    //    few times over ~5 seconds, then check LSPosed Manager > Logs and
    //    search for "DIAG". Send those lines back so the real call chain
    //    can be pinpointed precisely.
    // ---------------------------------------------------------------
    private void hookDiagnosticLogging(XC_LoadPackage.LoadPackageParam lpparam) {
        // (a) Log every CaptureRequest.Builder.set() call whose key name
        //     contains "zoom" - catches BOTH the standard Camera2 key and
        //     any vendor/proprietary key, whatever its real name is.
        try {
            XposedHelpers.findAndHookMethod(
                    CaptureRequest.Builder.class, "set",
                    CaptureRequest.Key.class, Object.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            try {
                                CaptureRequest.Key<?> key = (CaptureRequest.Key<?>) param.args[0];
                                if (key == null) return;
                                String name = key.getName();
                                if (name == null) return;
                                String lower = name.toLowerCase();
                                // Broadened beyond just "zoom": also catch the classic
                                // Android crop-based zoom mechanism (SCALER_CROP_REGION)
                                // and anything else that could plausibly drive the visible
                                // framing, in case "zoom" isn't literally in the key name.
                                if (lower.contains("zoom") || lower.contains("crop")
                                        || lower.contains("scal") || lower.contains("region")
                                        || lower.contains("fov")) {
                                    Object value = param.args[1];
                                    String valueStr = (value != null && value.getClass().isArray())
                                            ? arrayToString(value) : String.valueOf(value);
                                    XposedBridge.log(TAG + " " + ("DIAG CaptureRequest.set key=" + name + " value=" + valueStr));
                                }
                            } catch (Throwable ignored) {
                            }
                        }
                    });
            XposedBridge.log(TAG + " " + ("DIAG hook on CaptureRequest.Builder.set installed"));
        } catch (Throwable t) {
            XposedBridge.log(TAG + " DIAG hook(a) failed: " + t);
        }

        // (b) Log every method containing "zoom" in MiCameraCompatBaseImpl.
        hookAllZoomMethodsAndLog(lpparam, MI_CAMERA_COMPAT_CLASS, "MiCameraCompat");

        // (c) Log EVERY method in aa.k (ZoomManager) - not just ones with
        //     "zoom" in the name, since this class is obfuscated and its
        //     method names are meaningless single/double letters.
        hookAllMethodsAndLog(lpparam, ZOOM_MANAGER_CLASS, "ZoomManager(aa.k)");

        // (d) Log every method containing "zoom" in the main zoom UI fragment.
        hookAllZoomMethodsAndLog(lpparam,
                "com.android.camera.fragment.dual.FragmentDualCameraAdjust", "FragmentDualCameraAdjust");

        // (e) Log every method containing "zoom" in the toggle-button view.
        hookAllZoomMethodsAndLog(lpparam,
                "com.android.camera.ui.zoom.ZoomRatioToggleView", "ZoomRatioToggleView");
    }

    private String arrayToString(Object arr) {
        try {
            if (arr instanceof int[]) return java.util.Arrays.toString((int[]) arr);
            if (arr instanceof float[]) return java.util.Arrays.toString((float[]) arr);
            if (arr instanceof Object[]) return java.util.Arrays.deepToString((Object[]) arr);
        } catch (Throwable ignored) {
        }
        return String.valueOf(arr);
    }

    private void hookAllZoomMethodsAndLog(XC_LoadPackage.LoadPackageParam lpparam, String className, String shortTag) {
        try {
            Class<?> clazz = XposedHelpers.findClass(className, lpparam.classLoader);
            int count = 0;
            for (java.lang.reflect.Method m : clazz.getDeclaredMethods()) {
                if (!m.getName().toLowerCase().contains("zoom")) continue;
                final String methodName = m.getName();
                try {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            XposedBridge.log(TAG + " DIAG " + shortTag + "." + methodName
                                    + " args=" + java.util.Arrays.toString(param.args));
                        }
                    });
                    count++;
                } catch (Throwable ignored) {
                    // some methods (e.g. synthetic/bridge) may fail to hook; skip them
                }
            }
            XposedBridge.log(TAG + " " + ("DIAG hooked " + count + " zoom-named method(s) in " + shortTag));
        } catch (Throwable t) {
            XposedBridge.log(TAG + " DIAG could not load class " + className + ": " + t);
        }
    }

    private void hookAllMethodsAndLog(XC_LoadPackage.LoadPackageParam lpparam, String className, String shortTag) {
        try {
            Class<?> clazz = XposedHelpers.findClass(className, lpparam.classLoader);
            int count = 0;
            for (java.lang.reflect.Method m : clazz.getDeclaredMethods()) {
                final String methodName = m.getName();
                try {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            XposedBridge.log(TAG + " DIAG " + shortTag + "." + methodName
                                    + " args=" + java.util.Arrays.toString(param.args));
                        }
                    });
                    count++;
                } catch (Throwable ignored) {
                }
            }
            XposedBridge.log(TAG + " " + ("DIAG hooked " + count + " method(s) in " + shortTag));
        } catch (Throwable t) {
            XposedBridge.log(TAG + " DIAG could not load class " + className + ": " + t);
        }
    }

    // ---------------------------------------------------------------
    // 1) PRIORITY HOOK: synchronous, in-place easing applied directly on
    //    aa.k (ZoomManager) . b0(float, int).
    //
    //    CONFIRMED via direct evidence in the decompiled bytecode: onScale()
    //    - the real pinch-gesture handler - computes the new zoom ratio and,
    //    as its very last action, calls b0(ratio, someFlag). This is a much
    //    stronger signal than our earlier attempts:
    //      - applyTrackFocusZoom/applyUserZoom: proven via a screen-recorded
    //        test to have NO visible effect on the ring/number at all.
    //      - aa.k.setZoomRatio(float): tried, no visible effect either.
    //      - FragmentZoomRing.df(float,int): had a real log string proving
    //        it updates a native ValueAnimator, but in practice was never
    //        actually called during normal drag or tap interactions.
    //    b0(float,int) is different: it's called directly, every time,
    //    right at the end of the actual pinch handler - and its exact
    //    (float,int) signature also matches the pattern a reference "Camera
    //    Zoom Mod" tweak (for a different/POCO device) hooks under a
    //    differently-obfuscated name for the same purpose.
    //
    //    Smoothing here is done SYNCHRONOUSLY, in-place, with plain math -
    //    no Handler, no ValueAnimator, no reflective call-back into the app.
    //    Every earlier version that added any kind of active/async driving
    //    mechanism caused visible camera lag on this device, so this version
    //    deliberately avoids all of that.
    // ---------------------------------------------------------------

    private static final java.util.Map<String, Float> lastLoggedByMethod = new java.util.concurrent.ConcurrentHashMap<>();
    private static volatile float displayedRatio = -1f;
    private static volatile int lastObservedFlag = 0;

    // Lazily created - creating a Handler(Looper.getMainLooper()) as an eager
    // static field can throw if this class happens to be loaded before the
    // app process's main Looper is fully prepared, which would make the
    // WHOLE class fail to load (silently breaking every hook in this file).
    // Deferring creation until actually needed avoids that race entirely.
    private static volatile Handler mainHandler;

    private static Handler getMainHandler() {
        Handler h = mainHandler;
        if (h == null) {
            synchronized (MainHook.class) {
                h = mainHandler;
                if (h == null) {
                    h = new Handler(Looper.getMainLooper());
                    mainHandler = h;
                }
            }
        }
        return h;
    }

    private void hookCaptureRequestZoom(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            Class<?> zoomManagerClass = XposedHelpers.findClass(ZOOM_MANAGER_CLASS, lpparam.classLoader);
            installSmoothingHookOnB0(zoomManagerClass);
            installSmoothingHookOnSetZoomRatio(zoomManagerClass);
        } catch (Throwable t) {
            XposedBridge.log(TAG + " Failed to load " + ZOOM_MANAGER_CLASS + ": " + t);
        }
        // Found by reading setZoomRatio's own bytecode: AFTER it commits the
        // ratio into aa.k's own field (the one the UI number reads from),
        // it calls out to these two separate "data" manager classes. Since
        // the UI-relevant field is already committed by that point, hooking
        // these instead should let us smooth the real applied value WITHOUT
        // touching whatever the number displays.
        try {
            Class<?> dataKClass = XposedHelpers.findClass("com.android.camera.data.data.k", lpparam.classLoader);
            installSmoothingHookOnDataK(dataKClass);
        } catch (Throwable t) {
            XposedBridge.log(TAG + " Failed to load com.android.camera.data.data.k: " + t);
        }
        try {
            Class<?> dataG0Class = XposedHelpers.findClass("com.android.camera.data.data.g0", lpparam.classLoader);
            installSmoothingHookOnDataG0(dataG0Class);
        } catch (Throwable t) {
            XposedBridge.log(TAG + " Failed to load com.android.camera.data.data.g0: " + t);
        }
    }

    private void installSmoothingHookOnDataK(Class<?> dataKClass) {
        final String methodName = "h1";
        try {
            XposedHelpers.findAndHookMethod(
                    dataKClass,
                    methodName,
                    float.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            try {
                                float incomingTarget = (Float) param.args[0];
                                float target = trueTarget > 0f ? trueTarget : incomingTarget;

                                float lastLogged = lastLoggedByMethod.getOrDefault(methodName, -999f);
                                if (Math.abs(incomingTarget - lastLogged) > 0.02f) {
                                    lastLoggedByMethod.put(methodName, incomingTarget);
                                    XposedBridge.log(TAG + " data.k." + methodName + " raw=" + incomingTarget
                                            + " durationMs=" + getDurationMs());
                                }

                                if (displayedRatio < 0f) {
                                    displayedRatio = target;
                                    param.args[0] = displayedRatio;
                                    return;
                                }
                                float durationMs = getDurationMs();
                                if (durationMs > 1f) {
                                    float alpha = clamp(60f / durationMs, 0.005f, 1.0f);
                                    displayedRatio = displayedRatio + (target - displayedRatio) * alpha;
                                } else {
                                    displayedRatio = target;
                                }
                                param.args[0] = displayedRatio;
                            } catch (Throwable t) {
                                XposedBridge.log(TAG + " data.k." + methodName + " smoothing error: " + t);
                            }
                        }
                    }
            );
            XposedBridge.log(TAG + " com.android.camera.data.data.k.h1 hooked OK");
        } catch (Throwable t) {
            XposedBridge.log(TAG + " Failed to hook data.k.h1: " + t);
        }
    }

    private void installSmoothingHookOnDataG0(Class<?> dataG0Class) {
        final String methodName = "o0";
        try {
            XposedHelpers.findAndHookMethod(
                    dataG0Class,
                    methodName,
                    float.class,
                    int.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            try {
                                float incomingTarget = (Float) param.args[0];
                                float target = trueTarget > 0f ? trueTarget : incomingTarget;

                                if (displayedRatio < 0f) {
                                    param.args[0] = target;
                                    return;
                                }
                                // Reuse the same displayedRatio state that
                                // installSmoothingHookOnDataK already advances,
                                // so both downstream calls stay consistent with
                                // each other instead of drifting independently.
                                param.args[0] = displayedRatio;
                            } catch (Throwable t) {
                                XposedBridge.log(TAG + " data.g0." + methodName + " smoothing error: " + t);
                            }
                        }
                    }
            );
            XposedBridge.log(TAG + " com.android.camera.data.data.g0.o0 hooked OK");
        } catch (Throwable t) {
            XposedBridge.log(TAG + " Failed to hook data.g0.o0: " + t);
        }
    }

    // b0's own bytecode shows it FIRST commits the clamped ratio to its
    // internal UI-relevant field, THEN calls its own setZoomRatio(float) as
    // a downstream step. That ordering means modifying setZoomRatio's
    // argument should smooth the real/hardware-facing effect without
    // touching whatever the on-screen number already read from the
    // already-committed field - unlike modifying b0's own argument
    // directly, which corrupted that field and desynced the number.
    private void installSmoothingHookOnSetZoomRatio(Class<?> zoomManagerClass) {
        final String methodName = "setZoomRatio";
        try {
            XposedHelpers.findAndHookMethod(
                    zoomManagerClass,
                    methodName,
                    float.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            // OBSERVE ONLY - do not modify args[0]. Modifying the
                            // real zoom ratio (here or in b0) was proven to
                            // desync the on-screen number/ring, because Xiaomi's
                            // own UI reads the SAME internal field this writes to.
                            // The visual "delay" effect is now done purely at the
                            // rendering layer instead (see updateVisualZoomEffect).
                            try {
                                float incomingTarget = (Float) param.args[0];
                                float lastLogged = lastLoggedByMethod.getOrDefault(methodName, -999f);
                                if (Math.abs(incomingTarget - lastLogged) > 0.02f) {
                                    lastLoggedByMethod.put(methodName, incomingTarget);
                                    XposedBridge.log(TAG + " " + methodName + " raw=" + incomingTarget);
                                }
                                trueTarget = incomingTarget;
                                // startVisualZoomEffectIfNeeded(); // disabled - trying data.k/g0 hook instead
                            } catch (Throwable t) {
                                XposedBridge.log(TAG + " " + methodName + " observe error: " + t);
                            }
                        }
                    }
            );
            XposedBridge.log(TAG + " " + (ZOOM_MANAGER_CLASS + "." + methodName + " hooked OK (observe-only)"));
        } catch (Throwable t) {
            XposedBridge.log(TAG + " Failed to hook " + methodName + " (app may have updated): " + t);
        }
    }

    // aa.k.b0(float, int) -> boolean: found by systematically searching the
    // WHOLE camera app for every method with a (float, int) signature -
    // exactly mirroring the search strategy used by a reference "Camera Zoom
    // Mod" tweak for a different (POCO) device, which tries several
    // similarly-shaped candidate methods (named "uj"/"l0"/"Y1" on their
    // build) rather than hardcoding one exact obfuscated name. b0(float,int)
    // was actually noted as "the function that applies the new zoom ratio,
    // called from onScale" all the way back in our very first static
    // analysis pass, but had never actually been hooked until now - we had
    // tried setZoomRatio(float) and FragmentZoomRing.df(float,int) instead,
    // both of which turned out not to be the real driver.
    private void installSmoothingHookOnB0(Class<?> zoomManagerClass) {
        final String methodName = "b0";
        try {
            XposedHelpers.findAndHookMethod(
                    zoomManagerClass,
                    methodName,
                    float.class,
                    int.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            try {
                                zoomManagerRef.set(param.thisObject);
                                // NOTE: we deliberately do NOT modify param.args[0]
                                // here anymore. Doing so caused the on-screen zoom
                                // number/ring to desync and jump erratically -
                                // b0 is what the UI reads its number from, so
                                // feeding it a lagging value corrupted the app's
                                // own internal state tracking. We only observe/log
                                // here now; the actual "delay" effect is faked
                                // purely visually instead (see
                                // startVisualZoomEffectIfNeeded/tickVisualZoomEffect
                                // below), by scaling the preview View itself -
                                // never touching any camera/zoom data at all, so
                                // the number stays perfectly accurate.
                                float incomingTarget = (Float) param.args[0];
                                lastObservedFlag = (Integer) param.args[1];

                                float lastLogged = lastLoggedByMethod.getOrDefault(methodName, -999f);
                                if (Math.abs(incomingTarget - lastLogged) > 0.02f) {
                                    lastLoggedByMethod.put(methodName, incomingTarget);
                                    XposedBridge.log(TAG + " " + methodName + " raw target=" + incomingTarget
                                            + " flag=" + lastObservedFlag);
                                }
                                trueTarget = incomingTarget;
                                // startVisualZoomEffectIfNeeded(); // disabled - trying data.k/g0 hook instead
                            } catch (Throwable t) {
                                XposedBridge.log(TAG + " " + methodName + " observe error: " + t);
                            }
                        }
                    }
            );
            XposedBridge.log(TAG + " " + (ZOOM_MANAGER_CLASS + "." + methodName + " hooked OK (observe-only)"));
        } catch (Throwable t) {
            XposedBridge.log(TAG + " Failed to hook " + methodName + " (app may have updated): " + t);
        }
    }

    // Downstream hook: smooths the value actually pushed toward the lens/
    // hardware, WITHOUT touching b0's argument - so the on-screen number
    // (sourced from b0) stays perfectly in sync with your real finger
    // position/target, while only the physical zoom motion itself lags.
    private static volatile float trueTarget = -1f;

    // ---------------------------------------------------------------
    // VISUAL-ONLY zoom smoothing: instead of touching any camera/zoom data
    // (which we proved always desyncs the on-screen number, since Xiaomi
    // reads the exact same internal field we'd have to modify), this fakes
    // a smooth zoom purely by applying a temporary counter-scale Matrix
    // transform directly on the camera preview View.
    //
    // How it works: when the real zoom ratio jumps from oldTarget to
    // newTarget (near-instantly, as designed by Xiaomi), the preview buffer
    // itself is ALREADY showing the fully-zoomed newTarget framing. We
    // don't touch that. Instead we scale the View itself by
    // (visualRatio / newTarget) - starting at (oldTarget / newTarget), i.e.
    // exactly cancelling the jump back to how it looked a moment ago - and
    // animate that extra scale factor smoothly up to 1.0 (no extra
    // transform) over the configured duration. The number/ring stays 100%
    // accurate (it was never touched); only the pixels visually ease into
    // the new framing. This is standard View.setScaleX/Y manipulation -
    // no reflection back into the camera app, so it cannot cause the kind
    // of camera-pipeline lag every earlier "active" approach caused.
    // ---------------------------------------------------------------
    private static final AtomicReference<android.view.View> previewViewRef = new AtomicReference<>();
    private static volatile float visualRatio = -1f;
    private static volatile boolean visualEffectRunning = false;

    private void startVisualZoomEffectIfNeeded() {
        if (visualEffectRunning) return;
        visualEffectRunning = true;
        getMainHandler().post(MainHook::tickVisualZoomEffect);
    }

    private static void tickVisualZoomEffect() {
        try {
            float target = trueTarget;
            if (target <= 0f) {
                visualEffectRunning = false;
                return;
            }
            if (visualRatio < 0f) {
                visualRatio = target; // first frame ever - nothing to ease from
            }

            float durationMs = getDurationMs();
            float alpha = durationMs > 1f ? clamp(60f / durationMs, 0.01f, 1.0f) : 1.0f;
            visualRatio = visualRatio + (target - visualRatio) * alpha;

            android.view.View preview = previewViewRef.get();
            if (preview != null && target > 0f) {
                float extraScale = visualRatio / target;
                extraScale = clamp(extraScale, 0.5f, 2.0f); // safety bounds
                preview.setScaleX(extraScale);
                preview.setScaleY(extraScale);
            }

            if (Math.abs(visualRatio - target) < 0.002f) {
                // Converged - snap exactly and stop ticking to save battery.
                visualRatio = target;
                if (preview != null) {
                    preview.setScaleX(1f);
                    preview.setScaleY(1f);
                }
                visualEffectRunning = false;
                return;
            }

            getMainHandler().postDelayed(MainHook::tickVisualZoomEffect, 16);
        } catch (Throwable t) {
            XposedBridge.log(TAG + " tickVisualZoomEffect error: " + t);
            visualEffectRunning = false;
        }
    }

    /**
     * Searches the Activity's view hierarchy for the camera preview surface
     * (TextureView or SurfaceView - Xiaomi's camera preview is one of
     * these, like virtually all Camera2-based apps) and remembers it so the
     * visual zoom effect above has something to apply its scale transform
     * to.
     */
    private static android.view.View findPreviewView(android.view.View root) {
        if (root instanceof android.view.TextureView || root instanceof android.view.SurfaceView) {
            // SurfaceView in particular often renders through a separate
            // compositing path that ignores setScaleX/Y called directly on
            // it. Scaling its PARENT container instead is a well-known
            // workaround that generally still visually affects it, since
            // the parent's transform affects how the child surface gets
            // positioned/clipped within the window.
            android.view.ViewParent parent = root.getParent();
            if (parent instanceof android.view.View) {
                return (android.view.View) parent;
            }
            return root;
        }
        if (root instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) root;
            for (int i = 0; i < group.getChildCount(); i++) {
                android.view.View found = findPreviewView(group.getChildAt(i));
                if (found != null) return found;
            }
        }
        return null;
    }

    // ---------------------------------------------------------------
    // 2) VERSION-SPECIFIC HOOK: aa.k (ZoomManager)
    // ---------------------------------------------------------------
    // (Note: setZoomRatio is called directly via XposedHelpers.callMethod in
    // applyZoomRatio() below for the overlay preset buttons, so no separate
    // cached Method/field is needed here.)

    private void hookZoomManagerInternal(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            Class<?> zoomManagerClass = XposedHelpers.findClass(ZOOM_MANAGER_CLASS, lpparam.classLoader);

            XposedBridge.hookAllConstructors(zoomManagerClass, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    zoomManagerRef.set(param.thisObject);
                    XposedBridge.log(TAG + " " + ("Captured ZoomManager instance: " + param.thisObject));
                    // (setZoomRatio Method no longer cached separately - see note above)
                }
            });

            try {
                XposedHelpers.findAndHookMethod(zoomManagerClass, "onScale", "g9.c",
                        new XC_MethodHook() {
                            @Override
                            protected void beforeHookedMethod(MethodHookParam param) {
                                // Reserved: fine-grained pinch-gesture speed tuning could
                                // go here once the exact scale-delta math is confirmed
                                // (needs a real decompiler like jadx to read safely).
                            }
                        });
                XposedBridge.log(TAG + " " + ("aa.k.onScale hooked OK"));
            } catch (Throwable t) {
                XposedBridge.log(TAG + " aa.k.onScale hook failed (app may have updated): " + t);
            }

        } catch (Throwable t) {
            XposedBridge.log(TAG + " ZoomManager (" + ZOOM_MANAGER_CLASS + ") not found - " +
                    "internal hooks skipped. Expected if Xiaomi updated the Camera app: " + t);
        }
    }

    // ---------------------------------------------------------------
    // 3) UI: floating preset buttons 0.6x / 1x / 2x / 5x
    // ---------------------------------------------------------------
    private void hookActivityForOverlay(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            // Hook the base Activity class's onResume() instead of guessing an
            // exact subclass method. This is guaranteed to exist (it's declared
            // directly on android.app.Activity), so it can't throw
            // NoSuchMethodError regardless of how Xiaomi structured their
            // Camera/CameraActivity/Fragment hierarchy internally. We then
            // filter to only act on activities that belong to the camera app's
            // own package, so it doesn't affect other apps or unrelated
            // activities within this same process.
            XposedHelpers.findAndHookMethod(Activity.class, "onResume", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    try {
                        Activity activity = (Activity) param.thisObject;
                        String className = activity.getClass().getName();
                        if (!className.startsWith("com.android.camera")) return;
                        XposedBridge.log(TAG + " " + ("onResume fired for " + className));

                        // Always try to (re-)find the preview surface, regardless
                        // of the overlay-buttons setting - the visual zoom effect
                        // needs it independently.
                        try {
                            android.view.ViewGroup root = activity.findViewById(android.R.id.content);
                            android.view.View preview = findPreviewView(root);
                            if (preview != null) {
                                previewViewRef.set(preview);
                                XposedBridge.log(TAG + " Preview view captured: " + preview.getClass().getName());
                            } else {
                                XposedBridge.log(TAG + " Preview view NOT found in view hierarchy");
                            }
                        } catch (Throwable t) {
                            XposedBridge.log(TAG + " findPreviewView error: " + t);
                        }

                        if (!getShowOverlay()) return;
                        addZoomOverlay(activity);
                    } catch (Throwable t) {
                        XposedBridge.log(TAG + " overlay inject error: " + t);
                    }
                }
            });
            XposedBridge.log(TAG + " " + ("Activity#onResume hooked OK (filtering by com.android.camera.*)"));
        } catch (Throwable t) {
            XposedBridge.log(TAG + " Failed to hook Activity#onResume: " + t);
        }
    }

    private static final String OVERLAY_TAG = "xzoom_overlay_bar";

    private void addZoomOverlay(Activity activity) {
        ViewGroup root = activity.findViewById(android.R.id.content);
        if (root == null) return;
        // Tag-based check instead of a single static flag: correctly re-adds
        // the overlay if the Activity is recreated (e.g. rotation), but
        // avoids duplicating it on repeated onResume calls for the same
        // instance.
        if (root.findViewWithTag(OVERLAY_TAG) != null) return;

        LinearLayout bar = new LinearLayout(activity);
        bar.setTag(OVERLAY_TAG);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setBackgroundColor(0x66000000);
        bar.setPadding(24, 12, 24, 12);

        float[] presets = {0.6f, 1f, 2f, 5f};
        for (float ratio : presets) {
            Button btn = new Button(activity);
            String label = (ratio == Math.floor(ratio)) ? ((int) ratio) + "x" : ratio + "x";
            btn.setText(label);
            btn.setAllCaps(false);
            btn.setTextColor(0xFFFFFFFF);
            btn.setBackgroundColor(0x00000000);
            btn.setOnClickListener(v -> applyZoomRatio(ratio));
            LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            btnLp.leftMargin = 8;
            btnLp.rightMargin = 8;
            bar.addView(btn, btnLp);
        }

        if (root instanceof FrameLayout) {
            FrameLayout.LayoutParams flp = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            flp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
            flp.topMargin = 120;
            root.addView(bar, flp);
        } else {
            root.addView(bar);
        }
    }

    private void applyZoomRatio(float ratio) {
        try {
            Object zm = zoomManagerRef.get();
            if (zm == null) {
                XposedBridge.log(TAG + " ZoomManager instance not captured yet, cannot set ratio");
                return;
            }
            XposedHelpers.callMethod(zm, "setZoomRatio", ratio);
            XposedBridge.log(TAG + " " + ("Applied zoom ratio " + ratio + "x via overlay button"));
        } catch (Throwable t) {
            XposedBridge.log(TAG + " applyZoomRatio failed: " + t);
        }
    }

    // ---------------------------------------------------------------
    // Preferences (via ContentProvider IPC - see PrefsProvider for why this
    // replaced the original XSharedPreferences approach: on-device testing
    // showed XSharedPreferences was silently always returning the default
    // value regardless of what was actually saved in the settings screen,
    // almost certainly due to SELinux blocking the raw cross-app file read).
    // ---------------------------------------------------------------
    private static android.content.Context getAppContext() {
        android.content.Context ctx = appContext;
        if (ctx != null) return ctx;
        try {
            Class<?> activityThreadClass = Class.forName("android.app.ActivityThread");
            Object app = XposedHelpers.callStaticMethod(activityThreadClass, "currentApplication");
            if (app instanceof android.content.Context) {
                ctx = (android.content.Context) app;
                appContext = ctx;
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + " getAppContext failed: " + t);
        }
        return ctx;
    }

    private static void refreshPrefsIfNeeded() {
        long now = System.currentTimeMillis();
        if (now - lastPrefsQueryTime < PREFS_CACHE_MS) return; // throttle IPC calls
        lastPrefsQueryTime = now;
        try {
            android.content.Context ctx = getAppContext();
            if (ctx == null) {
                XposedBridge.log(TAG + " refreshPrefsIfNeeded: getAppContext() returned null");
                return;
            }
            android.database.Cursor c = ctx.getContentResolver()
                    .query(PrefsProvider.CONTENT_URI, null, null, null, null);
            if (c == null) {
                XposedBridge.log(TAG + " refreshPrefsIfNeeded: query() returned NULL cursor "
                        + "(provider likely unreachable - possible package-visibility block)");
                return;
            }
            try {
                if (c.moveToFirst()) {
                    cachedDurationMs = c.getFloat(c.getColumnIndexOrThrow("zoom_duration_ms"));
                    cachedShowOverlay = c.getInt(c.getColumnIndexOrThrow("show_overlay")) != 0;
                    XposedBridge.log(TAG + " refreshPrefsIfNeeded: OK, got durationMs="
                            + cachedDurationMs + " showOverlay=" + cachedShowOverlay);
                } else {
                    XposedBridge.log(TAG + " refreshPrefsIfNeeded: cursor was empty (moveToFirst=false)");
                }
            } finally {
                c.close();
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + " refreshPrefsIfNeeded failed: " + t);
        }
    }

    private static float getDurationMs() {
        refreshPrefsIfNeeded();
        return cachedDurationMs;
    }

    private static boolean getShowOverlay() {
        refreshPrefsIfNeeded();
        return cachedShowOverlay;
    }

    private static float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }
}
