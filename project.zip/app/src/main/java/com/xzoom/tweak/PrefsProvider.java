package com.xzoom.tweak;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;

/**
 * Exposes this module's settings (zoom_duration_ms, show_overlay) via a
 * standard Android ContentProvider instead of relying on XSharedPreferences'
 * raw "read another app's private file directly" mechanism.
 *
 * Why: XSharedPreferences depends on the preference FILE being made
 * world-readable (chmod) and then read directly off disk by a different
 * app/process. On modern hardened ROMs (HyperOS included) SELinux's
 * mandatory access control can silently block this cross-app file read even
 * when the Unix permission bits say it's readable - the read call doesn't
 * throw in a way we can easily detect, it just quietly falls back to
 * whatever default value we coded, which is exactly the bug that was
 * happening here (durationMs was always 250.0 regardless of the slider).
 *
 * A ContentProvider is the officially sanctioned, SELinux-friendly way for
 * one app to expose data to another app's process, since it goes through
 * Binder IPC (the same mechanism system-level cross-app data sharing is
 * built on) rather than a raw filesystem peek.
 */
public class PrefsProvider extends ContentProvider {

    public static final String AUTHORITY = "com.xzoom.tweak.prefsprovider";
    public static final Uri CONTENT_URI = Uri.parse("content://" + AUTHORITY + "/prefs");

    private static final String PREFS_NAME = "zoom_prefs";

    @Override
    public boolean onCreate() {
        return true;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection,
                         String[] selectionArgs, String sortOrder) {
        SharedPreferences prefs = getContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        float durationMs = prefs.getFloat("zoom_duration_ms", 250f);
        boolean showOverlay = prefs.getBoolean("show_overlay", true);

        MatrixCursor cursor = new MatrixCursor(new String[]{"zoom_duration_ms", "show_overlay"});
        cursor.addRow(new Object[]{durationMs, showOverlay ? 1 : 0});
        return cursor;
    }

    @Override
    public String getType(Uri uri) {
        return "vnd.android.cursor.item/vnd.com.xzoom.tweak.prefs";
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        return null; // not used - settings are written directly by SettingsActivity
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        return 0; // not used
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        return 0; // not used
    }
}
