package com.xzoom.tweak;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.util.Locale;

/**
 * Plain settings screen. Values are written to a SharedPreferences file
 * ("zoom_prefs") that is then made world-readable so MainHook (running
 * inside com.android.camera's process via LSPosed) can read it through
 * XSharedPreferences.
 *
 * The slider stores a single value directly consumed by the hook: "alpha",
 * the fraction of the remaining distance to the target zoom ratio that gets
 * applied on every single camera callback.
 *   alpha = 1.0  -> jump straight to target (no smoothing, stock behaviour)
 *   alpha = 0.02 -> only close 2% of the gap per callback (very slow/smooth)
 *
 * The slider itself uses a LOGARITHMIC (not linear) mapping from progress
 * (0-100) to alpha, because the perceptually useful range is not evenly
 * spread out: confirmed on-device testing showed alpha values from ~0.5
 * upward all feel basically identical ("normal"), while the interesting,
 * clearly-noticeable smoothing happens below ~0.2. A linear slider would
 * waste most of its length on the "feels the same" zone. The log mapping
 * spreads the whole 0-100 range evenly across that perceptually meaningful
 * span instead.
 */
public class SettingsActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "zoom_prefs";

    // alpha range covered by the slider
    private static final float ALPHA_MIN = 0.003f; // progress = 0   (paling halus/lambat banget)
    private static final float ALPHA_MAX = 1.0f;   // progress = 100 (normal/instan, tanpa smoothing)
    private static final float ALPHA_RATIO = ALPHA_MAX / ALPHA_MIN; // = 50

    private SeekBar seekSpeed;
    private TextView tvSpeedValue;
    private Switch switchOverlay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        seekSpeed = findViewById(R.id.seekSpeed);
        tvSpeedValue = findViewById(R.id.tvSpeedValue);
        switchOverlay = findViewById(R.id.switchOverlay);
        Button btnSave = findViewById(R.id.btnSave);

        seekSpeed.setMax(100);

        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        float savedAlpha = prefs.getFloat("zoom_alpha", 0.14f);
        boolean savedOverlay = prefs.getBoolean("show_overlay", true);

        seekSpeed.setProgress(alphaToProgress(savedAlpha));
        updateSpeedLabel(savedAlpha);
        switchOverlay.setChecked(savedOverlay);

        seekSpeed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                updateSpeedLabel(progressToAlpha(progress));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) { }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) { }
        });

        btnSave.setOnClickListener(v -> {
            float alpha = progressToAlpha(seekSpeed.getProgress());
            boolean overlay = switchOverlay.isChecked();

            prefs.edit()
                    .putFloat("zoom_alpha", alpha)
                    .putBoolean("show_overlay", overlay)
                    .apply();

            makeWorldReadable();

            Toast.makeText(this,
                    "Tersimpan. Tutup paksa (force-stop) aplikasi Kamera lalu buka lagi.",
                    Toast.LENGTH_LONG).show();
        });
    }

    // progress 0..100 (int)  <->  alpha ALPHA_MIN..ALPHA_MAX (log scale)
    private float progressToAlpha(int progress) {
        double t = progress / 100.0;
        return (float) (ALPHA_MIN * Math.pow(ALPHA_RATIO, t));
    }

    private int alphaToProgress(float alpha) {
        double t = Math.log(alpha / ALPHA_MIN) / Math.log(ALPHA_RATIO);
        int progress = (int) Math.round(t * 100.0);
        return Math.max(0, Math.min(100, progress));
    }

    private void updateSpeedLabel(float alpha) {
        String tag;
        if (alpha < 0.06f) {
            tag = "(sangat halus & lambat)";
        } else if (alpha < 0.20f) {
            tag = "(halus & lambat)";
        } else if (alpha < 0.5f) {
            tag = "(agak halus)";
        } else if (alpha < 0.9f) {
            tag = "(mendekati normal)";
        } else {
            tag = "(normal, tanpa smoothing)";
        }
        tvSpeedValue.setText(String.format(Locale.getDefault(), "alpha=%.3f %s", alpha, tag));
    }

    /**
     * Standard trick so the app running under a different UID (the Camera
     * app, via LSPosed) can read this SharedPreferences file through
     * XSharedPreferences.
     */
    private void makeWorldReadable() {
        try {
            File prefsDir = new File(getApplicationInfo().dataDir, "shared_prefs");
            File prefsFile = new File(prefsDir, PREFS_NAME + ".xml");
            prefsDir.setExecutable(true, false);
            prefsDir.setReadable(true, false);
            if (prefsFile.exists()) {
                prefsFile.setReadable(true, false);
            }
        } catch (Throwable ignored) {
            // Non-fatal - on some OEM ROMs SELinux may still block XSharedPreferences
            // entirely, which is a known LSPosed limitation, not a bug in this module.
        }
    }
}
