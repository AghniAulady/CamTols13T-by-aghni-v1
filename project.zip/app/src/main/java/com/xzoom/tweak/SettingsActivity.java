package com.xzoom.tweak;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.util.Locale;

/**
 * Settings screen for the zoom-easing duration, matching the design of a
 * similar working "Camera Zoom Mod" tweak found for POCO devices: a direct
 * "easing duration in milliseconds" slider (1-900ms), rather than an
 * abstract per-callback smoothing factor. Higher = slower/smoother glide.
 *
 * Values are written to a SharedPreferences file ("zoom_prefs") that is
 * then made world-readable so MainHook (running inside com.android.camera's
 * process via LSPosed) can read it through XSharedPreferences.
 */
public class SettingsActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "zoom_prefs";
    private static final int MAX_DURATION_MS = 900;

    private SeekBar seekSpeed;
    private TextView tvSpeedValue;
    private Switch switchOverlay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        seekSpeed = findViewById(R.id.seekSpeed);
        tvSpeedValue = findViewById(R.id.tvSpeedValue);
        switchOverlay = findViewById(R.id.switchOverlay);
        Button btnSave = findViewById(R.id.btnSave);

        seekSpeed.setMax(MAX_DURATION_MS);

        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        float savedDuration = prefs.getFloat("zoom_duration_ms", 250f);
        boolean savedOverlay = prefs.getBoolean("show_overlay", true);

        seekSpeed.setProgress(Math.round(savedDuration));
        updateSpeedLabel(savedDuration);
        switchOverlay.setChecked(savedOverlay);

        seekSpeed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                updateSpeedLabel(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) { }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) { }
        });

        btnSave.setOnClickListener(v -> {
            float durationMs = seekSpeed.getProgress();
            boolean overlay = switchOverlay.isChecked();

            prefs.edit()
                    .putFloat("zoom_duration_ms", durationMs)
                    .putBoolean("show_overlay", overlay)
                    .apply();

            makeWorldReadable();

            Toast.makeText(this,
                    "Tersimpan. Tutup paksa (force-stop) aplikasi Kamera lalu buka lagi.",
                    Toast.LENGTH_LONG).show();
        });
    }

    private void updateSpeedLabel(float durationMs) {
        String tag;
        if (durationMs < 1f) {
            tag = "(mati, normal/instan)";
        } else if (durationMs < 100f) {
            tag = "(halus tipis)";
        } else if (durationMs < 300f) {
            tag = "(halus & lambat)";
        } else if (durationMs < 600f) {
            tag = "(sangat halus & lambat)";
        } else {
            tag = "(paling lambat/glide panjang)";
        }
        tvSpeedValue.setText(String.format(Locale.getDefault(), "%.0f ms %s", durationMs, tag));
    }

    /**
     * Standard trick so the app running under a different UID (the Camera
     * app, via LSPosed) can read this SharedPreferences file through
     * XSharedPreferences.
     */
    private void makeWorldReadable() {
        try {
            File prefsDir = new File(getApplicationInfo().dataDir, "shared_prefs");
            File prefsFile = new File(prefsDir, PREFS_NAME + ".xml");
            prefsDir.setExecutable(true, false);
            prefsDir.setReadable(true, false);
            if (prefsFile.exists()) {
                prefsFile.setReadable(true, false);
            }
        } catch (Throwable ignored) {
            // Non-fatal - on some OEM ROMs SELinux may still block XSharedPreferences
            // entirely, which is a known LSPosed limitation, not a bug in this module.
        }
    }
}
