# ZoomSmooth — LSPosed module untuk Xiaomi 13T (com.android.camera)

Modul ini adalah rekonstruksi dari mod "Camera Zoom Mod 8.0" (awalnya untuk
Poco F7), ditulis ulang khusus menargetkan build Camera bawaan Xiaomi 13T
**6.1.000650.0** (`Kamera_6_1_000650_0.apk` yang kamu upload).

## Bagaimana target ditemukan

Karena kamu tidak punya source code aslinya, target hook didapat lewat
analisis statis (dex parsing + disassembly manual bytecode, tanpa
jadx/apktool):

- Class utama zoom di Camera 13T: `aa.k` (implementasi), interface
  induk `aa.a`. Dipakai lewat `com.android.camera.module.q0` (mode foto).
- Method yang cocok dengan pola pencarian mod asli — parameter
  `(float, int)`, return `boolean` — adalah **`b0(float, int): boolean`**.
- Algoritma smoothing hasil bongkar bytecode `CameraZoomHooks` di mod F7:
  - durasi transisi default **300 ms** (clamp 1–900 ms)
  - time-constant `tau = durasi * 0.4`
  - tiap frame: `alpha = clamp(1 - exp(-dt/tau), 0.01, 1.0)`,
    `current += (target - current) * alpha`
  - berhenti kalau `|target - current| < 0.001`

Kode di `ZoomSmoothHook.kt` mereplikasi persis rumus ini.

## ⚠️ Yang perlu kamu tahu sebelum pakai

1. **Belum diverifikasi jalan di perangkat asli.** Saya tidak bisa
   menjalankan LSPosed/APK ini di HP fisik dari sini — semua berdasar
   analisis statis. Nama class `aa.k` valid untuk build APK yang kamu
   upload; kalau kamera di HP-mu sudah OTA ke versi lain, class ini bisa
   berbeda lagi.
2. **Cara cek cepat setelah install** — lihat Logcat:
   ```
   adb logcat -s ZoomSmooth
   ```
   - Kalau muncul `[ZOOM] ✓ hooked aa.k.b0(float,int) — smooth zoom aktif`
     → hook berhasil terpasang.
   - Kalau muncul `[ZOOM] tidak ketemu method target...` → berarti
     `aa.k`/`b0` tidak ada di runtime (mungkin di-strip berbeda oleh
     ProGuard per varian/region), dan kamu perlu kirim saya hasil
     `adb logcat` + (kalau bisa) APK Camera versi yang sedang jalan biar
     saya sesuaikan lagi.
3. Ini genuinely reverse-engineering murni: saya tidak menjamin `b0`
   memang benar-benar "zoom ratio setter yang dipanggil UI" — itu
   kandidat PALING KUAT berdasar signature matching, sama seperti cara
   mod aslinya bekerja, tapi validasi final cuma bisa lewat tes di HP.

## Build

Butuh Android Studio + dependency `io.github.libxposed:api` (repo
JitPack/Maven sesuai instruksi resmi libxposed). Struktur proyek:

```
src/main/kotlin/com/example/zoomsmooth/HookEntry.kt
src/main/kotlin/com/example/zoomsmooth/ZoomSmoothHook.kt
src/main/resources/META-INF/xposed/module.prop
src/main/resources/META-INF/xposed/scope.list
src/main/resources/META-INF/xposed/java_init.list
```

Tambahkan ke `build.gradle.kts` modul app:
```kotlin
dependencies {
    compileOnly("io.github.libxposed:api:102.0.0") // sesuaikan versi
}
```

`AndroidManifest.xml` app perlu `android:label`/`android:description`
standar (module.prop hanya untuk minApiVersion/targetApiVersion/staticScope
sesuai dokumentasi libxposed terbaru). Aktifkan modul & pilih scope
`com.android.camera` di LSPosed Manager, lalu **restart aplikasi Kamera**
(bukan cuma reboot modul).

## Kalau hook gagal

Kirim ke saya:
- output `adb logcat -s ZoomSmooth`
- (kalau memungkinkan) `adb pull` ulang APK Camera yang sedang aktif di HP
  (`adb shell pm path com.android.camera`)

biar saya cek ulang apakah `aa.k`/`b0` sudah berubah nama di build
yang sedang jalan di HP-mu.
