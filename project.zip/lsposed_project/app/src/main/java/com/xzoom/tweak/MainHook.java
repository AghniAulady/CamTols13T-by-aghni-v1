package com.xzoom.tweak;

import android.app.Activity;
import android.hardware.camera2.CaptureRequest;
import android.util.Log;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import java.util.concurrent.atomic.AtomicReference;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XSharedPreferences;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * LSPosed module for Kamera Xiaomi (com.android.camera).
 *
 * Analyzed against APK version 6.1.000650.0. Two layers of hooks are used:
 *
 *  1) PRIORITY hook on
 *     com.android.camera2.compat.MiCameraCompatBaseImpl#applyUserZoom(
 *     CaptureRequest.Builder, float). Confirmed via static analysis to be
 *     the actual method Xiaomi's camera pipeline calls every frame to push
 *     the live zoom ratio. This is where "zoom speed" and "smoothing" are
 *     implemented. (A previous version of this module hooked the standard
 *     Camera2 CONTROL_ZOOM_RATIO key directly, but this app never calls
 *     that key path, so that hook never fired - fixed here.)
 *
 *  2) App-internal hooks on the obfuscated ZoomManager class ("aa.k") that
 *     were identified via static analysis of this specific APK build. These
 *     are used only to (a) grab a live ZoomManager instance so our overlay
 *     buttons can call setZoomRatio() directly, and (b) as a placeholder for
 *     future fine-tuning. If Xiaomi updates the Camera app, the obfuscated
 *     name "aa.k" will very likely change and this layer will simply fail to
 *     attach (logged, not fatal) - hook #1 keeps working regardless.
 */
public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "XZoomTweak";
    private static final String TARGET_PACKAGE = "com.android.camera";

    // Obfuscated class name for the ZoomManager implementation, valid for
    // Kamera 6.1.000650.0. Re-check with the dex analysis steps in
    // README.md if this ever stops working after an app update.
    private static final String ZOOM_MANAGER_CLASS = "aa.k";
    private static final String CAMERA_ACTIVITY_CLASS = "com.android.camera.Camera";

    private static XSharedPreferences prefs;
    private static final AtomicReference<Object> zoomManagerRef = new AtomicReference<>();
    private static float lastAppliedRatio = -1f;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!TARGET_PACKAGE.equals(lpparam.packageName)) {
            return;
        }

        prefs = new XSharedPreferences("com.xzoom.tweak", "zoom_prefs");
        prefs.makeWorldReadable();

        Log.i(TAG, "Loaded into " + lpparam.packageName + " (process=" + lpparam.processName + ")");

        hookCaptureRequestZoom(lpparam);
        hookZoomManagerInternal(lpparam);
        hookActivityForOverlay(lpparam);
    }

    // ---------------------------------------------------------------
    // 1) PRIORITY HOOK: MiCameraCompatBaseImpl.applyUserZoom(Builder, float)
    //    Confirmed via static analysis: this is the exact method+signature
    //    Xiaomi's camera pipeline calls every frame to push the live zoom
    //    ratio onto the CaptureRequest builder. Unlike the standard
    //    Camera2 CONTROL_ZOOM_RATIO key (which this app does NOT appear to
    //    call directly - that's why the previous version never triggered),
    //    this is the real choke point for this build.
    // ---------------------------------------------------------------
    private static final String MI_CAMERA_COMPAT_CLASS =
            "com.android.camera2.compat.MiCameraCompatBaseImpl";

    private void hookCaptureRequestZoom(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            Class<?> compatClass = XposedHelpers.findClass(MI_CAMERA_COMPAT_CLASS, lpparam.classLoader);

            XposedHelpers.findAndHookMethod(
                    compatClass,
                    "applyUserZoom",
                    CaptureRequest.Builder.class,
                    float.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            try {
                                float targetRatio = (Float) param.args[1];
                                float speed = getSpeedMultiplier();
                                boolean smoothEnabled = getSmoothEnabled();

                                Log.i(TAG, "applyUserZoom called, target=" + targetRatio
                                        + " speed=" + speed + " smooth=" + smoothEnabled);

                                if (!smoothEnabled && speed == 1.0f) {
                                    lastAppliedRatio = targetRatio;
                                    return; // stock behaviour
                                }

                                float newRatio = targetRatio;
                                if (lastAppliedRatio > 0f) {
                                    if (smoothEnabled) {
                                        // Exponential smoothing towards the target ratio.
                                        // Lower speed => smaller alpha => slower, smoother motion.
                                        float alpha = clamp(speed * 0.5f, 0.03f, 1.0f);
                                        newRatio = lastAppliedRatio + (targetRatio - lastAppliedRatio) * alpha;
                                    } else {
                                        // Speed-only: rate-limit how fast the ratio can change per call.
                                        float maxStep = 0.15f * speed;
                                        float delta = targetRatio - lastAppliedRatio;
                                        if (Math.abs(delta) > maxStep) {
                                            newRatio = lastAppliedRatio + Math.signum(delta) * maxStep;
                                        }
                                    }
                                }
                                lastAppliedRatio = newRatio;
                                param.args[1] = newRatio;
                            } catch (Throwable t) {
                                XposedBridge.log(TAG + " hookCaptureRequestZoom error: " + t);
                            }
                        }
                    }
            );
            Log.i(TAG, MI_CAMERA_COMPAT_CLASS + ".applyUserZoom hooked OK");
        } catch (Throwable t) {
            XposedBridge.log(TAG + " Failed to hook applyUserZoom (app may have updated): " + t);
        }
    }

    // ---------------------------------------------------------------
    // 2) VERSION-SPECIFIC HOOK: aa.k (ZoomManager)
    // ---------------------------------------------------------------
    private void hookZoomManagerInternal(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            Class<?> zoomManagerClass = XposedHelpers.findClass(ZOOM_MANAGER_CLASS, lpparam.classLoader);

            XposedBridge.hookAllConstructors(zoomManagerClass, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    zoomManagerRef.set(param.thisObject);
                    Log.i(TAG, "Captured ZoomManager instance: " + param.thisObject);
                }
            });

            try {
                XposedHelpers.findAndHookMethod(zoomManagerClass, "onScale", "g9.c",
                        new XC_MethodHook() {
                            @Override
                            protected void beforeHookedMethod(MethodHookParam param) {
                                // Reserved: fine-grained pinch-gesture speed tuning could
                                // go here once the exact scale-delta math is confirmed
                                // (needs a real decompiler like jadx to read safely).
                            }
                        });
                Log.i(TAG, "aa.k.onScale hooked OK");
            } catch (Throwable t) {
                XposedBridge.log(TAG + " aa.k.onScale hook failed (app may have updated): " + t);
            }

        } catch (Throwable t) {
            XposedBridge.log(TAG + " ZoomManager (" + ZOOM_MANAGER_CLASS + ") not found - " +
                    "internal hooks skipped. Expected if Xiaomi updated the Camera app: " + t);
        }
    }

    // ---------------------------------------------------------------
    // 3) UI: floating preset buttons 0.6x / 1x / 2x / 5x
    // ---------------------------------------------------------------
    private void hookActivityForOverlay(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            // Hook the base Activity class's onResume() instead of guessing an
            // exact subclass method. This is guaranteed to exist (it's declared
            // directly on android.app.Activity), so it can't throw
            // NoSuchMethodError regardless of how Xiaomi structured their
            // Camera/CameraActivity/Fragment hierarchy internally. We then
            // filter to only act on activities that belong to the camera app's
            // own package, so it doesn't affect other apps or unrelated
            // activities within this same process.
            XposedHelpers.findAndHookMethod(Activity.class, "onResume", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    try {
                        if (!getShowOverlay()) return;
                        Activity activity = (Activity) param.thisObject;
                        String className = activity.getClass().getName();
                        if (!className.startsWith("com.android.camera")) return;
                        Log.i(TAG, "onResume fired for " + className);
                        addZoomOverlay(activity);
                    } catch (Throwable t) {
                        XposedBridge.log(TAG + " overlay inject error: " + t);
                    }
                }
            });
            Log.i(TAG, "Activity#onResume hooked OK (filtering by com.android.camera.*)");
        } catch (Throwable t) {
            XposedBridge.log(TAG + " Failed to hook Activity#onResume: " + t);
        }
    }

    private static final String OVERLAY_TAG = "xzoom_overlay_bar";

    private void addZoomOverlay(Activity activity) {
        ViewGroup root = activity.findViewById(android.R.id.content);
        if (root == null) return;
        // Tag-based check instead of a single static flag: correctly re-adds
        // the overlay if the Activity is recreated (e.g. rotation), but
        // avoids duplicating it on repeated onResume calls for the same
        // instance.
        if (root.findViewWithTag(OVERLAY_TAG) != null) return;

        LinearLayout bar = new LinearLayout(activity);
        bar.setTag(OVERLAY_TAG);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setBackgroundColor(0x66000000);
        bar.setPadding(24, 12, 24, 12);

        float[] presets = {0.6f, 1f, 2f, 5f};
        for (float ratio : presets) {
            Button btn = new Button(activity);
            String label = (ratio == Math.floor(ratio)) ? ((int) ratio) + "x" : ratio + "x";
            btn.setText(label);
            btn.setAllCaps(false);
            btn.setTextColor(0xFFFFFFFF);
            btn.setBackgroundColor(0x00000000);
            btn.setOnClickListener(v -> applyZoomRatio(ratio));
            LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            btnLp.leftMargin = 8;
            btnLp.rightMargin = 8;
            bar.addView(btn, btnLp);
        }

        if (root instanceof FrameLayout) {
            FrameLayout.LayoutParams flp = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            flp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
            flp.topMargin = 120;
            root.addView(bar, flp);
        } else {
            root.addView(bar);
        }
    }

    private void applyZoomRatio(float ratio) {
        try {
            Object zm = zoomManagerRef.get();
            if (zm == null) {
                XposedBridge.log(TAG + " ZoomManager instance not captured yet, cannot set ratio");
                return;
            }
            XposedHelpers.callMethod(zm, "setZoomRatio", ratio);
            Log.i(TAG, "Applied zoom ratio " + ratio + "x via overlay button");
        } catch (Throwable t) {
            XposedBridge.log(TAG + " applyZoomRatio failed: " + t);
        }
    }

    // ---------------------------------------------------------------
    // Preferences
    // ---------------------------------------------------------------
    private static float getSpeedMultiplier() {
        try {
            prefs.reload();
            return prefs.getFloat("speed_multiplier", 1.0f);
        } catch (Throwable t) {
            return 1.0f;
        }
    }

    private static boolean getSmoothEnabled() {
        try {
            prefs.reload();
            return prefs.getBoolean("smooth_enabled", true);
        } catch (Throwable t) {
            return true;
        }
    }

    private static boolean getShowOverlay() {
        try {
            prefs.reload();
            return prefs.getBoolean("show_overlay", true);
        } catch (Throwable t) {
            return true;
        }
    }

    private static float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }
}
