pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        maven { url = uri("https://api.xposed.info") } // repo resmi libxposed
        maven { url = uri("https://jitpack.io") }
    }
}

rootProject.name = "ZoomSmooth13T"
include(":app")
